
export interface ComparisonStats {
  annualFee: string;
  purchaseApr: { min: string; max: string; percent: number };
  welcomeBonus: { text: string; subtext: string; color: string };
  earningRate: { icon: string; text: string }[];
  annualCredits: string[];
  creditScore: { label: string; score: string; percent: number };
}

export type CardFinish = 'obsidian' | 'titanium' | 'gold' | 'cobalt' | 'carbon' | 'rose-gold' | 'pearl' | 'matte-black';
export type BankName = 'HDFC BANK' | 'ICICI BANK' | 'AXIS BANK' | 'FEDERAL BANK' | 'HSBC' | 'AMEX' | 'KOTAK';

export interface CardBenefit {
  icon: string;
  title: string;
  desc: string;
}

export interface CreditCard {
  id: string;
  name: string;
  issuer: BankName;
  image: string;
  rewards: string;
  fee: string; // Display string for list view
  joiningFee: string;
  annualFee: string;
  type: 'Credit' | 'Debit' | 'Prepaid';
  category: string;
  badge: string;
  description: string;
  finish: CardFinish;
  stats: {
    label: string;
    value: string;
  }[];
  color: string;
  icon: string;
  detailedBenefits?: CardBenefit[];
  comparison?: ComparisonStats;
}

export interface CategoryMetadata {
  id: string;
  name: string;
  icon: string;
  desc: string;
  globalDeclaration: string;
  indiaDeclaration: string;
  benefits: string[];
  color: string;
}

export type AppView = 'home' | 'compare' | 'score' | 'gallery' | 'curated' | 'wallet' | 'billing' | 'finder' | 'debit' | 'prepaid' | 'loans' | 'offers' | 'benefits' | 'card-strategy' | 'guide' | 'category-detail';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export enum FeatureType {
  Compare = 'compare',
  Score = 'score',
  Personalized = 'personalized'
}

export interface GuideChapter {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  mentor: string;
  mentorQuote: string;
  topics: {
    title: string;
    description: string;
    riskLevel: 'Low' | 'Medium' | 'High';
    isLegal?: boolean;
  }[];
}
