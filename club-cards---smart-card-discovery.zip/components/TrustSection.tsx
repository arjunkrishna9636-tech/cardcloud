
import React from 'react';

const TrustSection: React.FC = () => {
  const partners = [
    { name: 'Chase', icon: 'account_balance' },
    { name: 'AMEX', icon: 'corporate_fare' },
    { name: 'CITI', icon: 'savings' },
    { name: 'HDFC', icon: 'assured_workload' },
    { name: 'Wells Fargo', icon: 'currency_exchange' }
  ];

  return (
    <section className="py-12 border-t border-gray-200 dark:border-border-dark bg-gray-50 dark:bg-[#0e1117]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-sm font-medium text-slate-500 mb-8 uppercase tracking-widest">Trusted by leading financial institutions</p>
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-60 grayscale dark:invert transition-all hover:grayscale-0 dark:hover:invert-0">
          {partners.map((p, i) => (
            <div key={i} className="h-8 flex items-center justify-center font-bold text-xl text-slate-800 dark:text-white">
              <span className="material-symbols-outlined mr-2">{p.icon}</span> {p.name}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
