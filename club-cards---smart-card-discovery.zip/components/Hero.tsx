
import React from 'react';

interface HeroProps {
  onFindCard: () => void;
}

const Hero: React.FC<HeroProps> = ({ onFindCard }) => {
  const stats = [
    {
      value: '2.3 Cr+',
      label: 'Users Checked Credit Score',
      icon: 'groups',
      color: 'text-blue-400'
    },
    {
      value: '10 Lakh+',
      label: 'Joined CreditFit Program',
      icon: 'workspace_premium',
      color: 'text-purple-400'
    },
    {
      value: '40+',
      label: 'Lending Partners',
      icon: 'handshake',
      color: 'text-emerald-400'
    },
    {
      value: '4.3',
      label: 'Average User Rating',
      icon: 'star',
      color: 'text-yellow-400'
    }
  ];

  return (
    <section className="relative overflow-hidden pt-16 pb-12 lg:pt-24 lg:pb-20">
      <div className="absolute top-0 right-0 -z-10 h-[600px] w-[600px] rounded-full bg-hero-gradient opacity-60 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 -z-10 h-[400px] w-[400px] rounded-full bg-hero-gradient opacity-30 blur-3xl translate-y-1/2"></div>
      
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="flex flex-col gap-6 max-w-2xl animate-in fade-in slide-in-from-left duration-1000">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-medium text-primary w-fit">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              New Platinum Rewards Added
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.05]">
              One Platform. <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">Every Credit Card.</span> <br/>
              Smarter Decisions.
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-lg font-medium">
              Unlock exclusive rewards and manage your financial health with the world's most comprehensive card discovery engine.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <button 
                onClick={onFindCard}
                className="h-14 px-10 rounded-xl bg-primary text-white font-black text-sm uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl shadow-primary/25 hover:shadow-primary/40 flex items-center gap-3"
              >
                <span className="material-symbols-outlined">search</span>
                Find my Card
              </button>
              <button className="h-14 px-10 rounded-xl border border-gray-300 dark:border-white/10 bg-white dark:bg-white/5 text-slate-900 dark:text-white font-black text-sm uppercase tracking-widest hover:bg-gray-50 dark:hover:bg-white/10 transition-all flex items-center gap-3">
                <span className="material-symbols-outlined">speed</span>
                Check Score
              </button>
            </div>
          </div>

          <div className="relative lg:h-auto min-h-[400px] flex items-center justify-center lg:justify-end animate-in fade-in slide-in-from-right duration-1000">
            <div className="relative w-full max-w-md aspect-[1.586] rounded-[32px] overflow-hidden shadow-[0_40px_100px_-20px_rgba(18,88,226,0.4)] border border-white/10 group bg-[#151b27]">
              <div className="absolute inset-0 bg-gradient-to-br from-[#1e2a4a] to-[#0f172a] opacity-90 group-hover:scale-110 transition-transform duration-700"></div>
              <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=lux')] opacity-5 mix-blend-overlay"></div>
              
              <div className="relative z-10 p-10 h-full flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-black tracking-widest text-lg uppercase">CLUB CARDS</span>
                  </div>
                  <span className="material-symbols-outlined text-white/20 text-4xl">contactless</span>
                </div>
                
                <div>
                   <div className="h-10 w-14 rounded-lg bg-yellow-500/20 border border-yellow-500/30 mb-8 relative">
                      <div className="absolute top-1/2 left-2 right-2 h-[2px] bg-yellow-500/20"></div>
                   </div>
                   <p className="text-white/40 font-mono tracking-[0.3em] text-lg mb-2">**** **** **** 8842</p>
                   <div className="flex justify-between items-end">
                      <div>
                        <p className="text-[10px] text-white/30 uppercase tracking-widest mb-1">Card Holder</p>
                        <p className="text-white font-bold tracking-widest uppercase">Premium Discovery</p>
                      </div>
                      <div className="size-12 rounded-full bg-white/5 flex items-center justify-center border border-white/10" onClick={onFindCard}>
                        <span className="material-symbols-outlined text-white/40">auto_awesome</span>
                      </div>
                   </div>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-6 -right-6 md:right-0 bg-white dark:bg-[#1c2331] p-6 rounded-3xl border border-gray-200 dark:border-white/10 shadow-2xl animate-bounce" style={{ animationDuration: '4s' }}>
              <div className="flex items-center gap-4">
                 <div className="size-12 rounded-2xl bg-green-500/10 flex items-center justify-center text-green-400">
                    <span className="material-symbols-outlined">trending_up</span>
                 </div>
                 <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Score Boost</p>
                    <p className="text-lg font-black dark:text-white">+42 Points</p>
                 </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-10 border-y border-gray-200 dark:border-white/5 animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-300">
          {stats.map((stat, i) => (
            <div key={i} className="flex flex-col items-center text-center px-4 group">
              <div className={`size-12 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center ${stat.color} mb-4 group-hover:scale-110 transition-transform`}>
                <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>{stat.icon}</span>
              </div>
              <p className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter mb-1">{stat.value}</p>
              <p className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest leading-tight max-w-[120px]">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
