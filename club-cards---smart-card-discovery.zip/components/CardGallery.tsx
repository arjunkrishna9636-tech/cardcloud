
import React, { useState } from 'react';
import { ALL_CARDS } from '../constants';
import RealisticCard from './RealisticCard';
import { BankName, CreditCard } from '../types';
import ApplicationDetailModal from './ApplicationDetailModal';

const BANKS: BankName[] = ['HDFC BANK', 'ICICI BANK', 'AXIS BANK', 'FEDERAL BANK', 'KOTAK', 'AMEX', 'HSBC'];

const CardGallery: React.FC = () => {
  const [activeType, setActiveType] = useState<'Credit' | 'Debit'>('Credit');
  const [activeBank, setActiveBank] = useState<BankName | 'All Banks'>('All Banks');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApplication, setSelectedApplication] = useState<CreditCard | null>(null);

  const filteredCards = ALL_CARDS.filter(card => {
    const matchesType = card.type === activeType;
    const matchesBank = activeBank === 'All Banks' || card.issuer === activeBank;
    const matchesSearch = card.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          card.issuer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesBank && matchesSearch;
  });

  const getBankCardCount = (bank: BankName) => {
    return ALL_CARDS.filter(c => c.issuer === bank && c.type === activeType).length;
  };

  return (
    <div className="min-h-screen bg-[#0a0f18] pb-24 animate-in fade-in duration-700">
      {/* Premium Marketplace Header */}
      <div className="relative pt-24 pb-16 overflow-hidden border-b border-white/5 bg-gradient-to-b from-[#0f172a] to-[#0a0f18]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,_#1258e210_0%,_transparent_50%)]"></div>
        <div className="max-w-[1440px] mx-auto px-8 w-full relative z-10">
          <div className="flex flex-col lg:flex-row justify-between items-center gap-12">
            <div className="max-w-2xl text-center lg:text-left">
              <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-[10px] font-black uppercase tracking-[0.4em] mb-6 border border-primary/20">
                <span className="material-symbols-outlined text-sm">shopping_cart</span>
                Official Banking Catalog
              </div>
              <h1 className="text-6xl lg:text-8xl font-black text-white tracking-tighter mb-8 leading-none">
                {activeBank === 'All Banks' ? 'Market' : activeBank.split(' ')[0]} <br/>
                <span className="text-primary italic">Instruments.</span>
              </h1>
              <p className="text-xl text-slate-400 font-medium leading-relaxed">
                Discover {activeBank === 'All Banks' ? 'global' : `official ${activeBank}`} {activeType.toLowerCase()} products. 
                Our discovery engine syncs directly with bank master directions.
              </p>
            </div>

            {/* Main Toggle Panels - Professional UI */}
            <div className="flex flex-col md:flex-row gap-6 p-4 bg-white/5 rounded-[40px] border border-white/5 backdrop-blur-3xl shadow-2xl">
              <button 
                onClick={() => setActiveType('Credit')}
                className={`group relative flex flex-col items-center gap-4 p-8 rounded-[32px] min-w-[200px] transition-all duration-500 border ${activeType === 'Credit' ? 'bg-primary border-primary shadow-2xl scale-105' : 'bg-transparent border-white/5 hover:border-white/10 hover:bg-white/5'}`}
              >
                <div className={`size-14 rounded-2xl flex items-center justify-center transition-colors ${activeType === 'Credit' ? 'bg-white/20 text-white' : 'bg-white/5 text-slate-500 group-hover:text-white'}`}>
                  <span className="material-symbols-outlined text-3xl">credit_card</span>
                </div>
                <div className="text-center">
                  <p className={`text-sm font-black uppercase tracking-widest ${activeType === 'Credit' ? 'text-white' : 'text-slate-500 group-hover:text-white'}`}>Credit Cards</p>
                  <p className={`text-[10px] font-bold mt-1 ${activeType === 'Credit' ? 'text-white/60' : 'text-slate-600'}`}>High Yield lines</p>
                </div>
              </button>

              <button 
                onClick={() => setActiveType('Debit')}
                className={`group relative flex flex-col items-center gap-4 p-8 rounded-[32px] min-w-[200px] transition-all duration-500 border ${activeType === 'Debit' ? 'bg-primary border-primary shadow-2xl scale-105' : 'bg-transparent border-white/5 hover:border-white/10 hover:bg-white/5'}`}
              >
                <div className={`size-14 rounded-2xl flex items-center justify-center transition-colors ${activeType === 'Debit' ? 'bg-white/20 text-white' : 'bg-white/5 text-slate-500 group-hover:text-white'}`}>
                  <span className="material-symbols-outlined text-3xl">account_balance_wallet</span>
                </div>
                <div className="text-center">
                  <p className={`text-sm font-black uppercase tracking-widest ${activeType === 'Debit' ? 'text-white' : 'text-slate-500 group-hover:text-white'}`}>Debit Cards</p>
                  <p className={`text-[10px] font-bold mt-1 ${activeType === 'Debit' ? 'text-white/60' : 'text-slate-600'}`}>Liquid Access</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-8 mt-12">
        {/* Advanced Bank Filters */}
        <div className="sticky top-[80px] z-40 bg-[#0a0f18]/80 backdrop-blur-xl py-8 border-b border-white/5 mb-16">
          <div className="flex flex-col gap-8">
            <div className="flex flex-col lg:flex-row justify-between items-center gap-6">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest mr-4">Select Bank:</span>
                <button
                  onClick={() => setActiveBank('All Banks')}
                  className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeBank === 'All Banks' ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
                >
                  All Banks
                </button>
                {BANKS.map(bank => (
                  <button
                    key={bank}
                    onClick={() => setActiveBank(bank)}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeBank === bank ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
                  >
                    {bank}
                    <span className={`px-1.5 py-0.5 rounded-md text-[8px] font-bold ${activeBank === bank ? 'bg-white/20 text-white' : 'bg-white/10 text-slate-500'}`}>
                      {getBankCardCount(bank)}
                    </span>
                  </button>
                ))}
              </div>
              
              <div className="relative w-full lg:w-[350px] group">
                <span className="material-symbols-outlined absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-primary transition-colors">search</span>
                <input
                  type="text"
                  placeholder={`Search ${activeBank === 'All Banks' ? '' : activeBank}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-white outline-none focus:ring-1 focus:ring-primary transition-all"
                />
              </div>
            </div>
          </div>
        </div>

        {/* The Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12">
          {filteredCards.map((card, i) => (
            <div 
              key={card.id} 
              className="flex flex-col animate-in fade-in slide-in-from-bottom-8 group"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="relative mb-8 perspective-[1000px]">
                 <RealisticCard 
                  card={card} 
                  className="group-hover:-translate-y-4 transition-transform duration-700 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.8)]" 
                 />
                 <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                    <p className="text-[9px] font-black text-white uppercase tracking-widest">Apply Now</p>
                 </div>
              </div>
              
              <div className="px-2">
                <div className="flex justify-between items-start mb-4">
                   <div>
                      <h3 className="text-2xl font-black text-white tracking-tight leading-none mb-1 group-hover:text-primary transition-colors">{card.name}</h3>
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">{card.issuer} • {card.category}</p>
                   </div>
                   <div className="flex flex-col items-end">
                      <span className="text-[9px] font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded uppercase mb-1">Official</span>
                      <span className="text-[8px] font-black text-slate-700 uppercase">{card.finish} Finish</span>
                   </div>
                </div>
                
                <p className="text-sm text-slate-500 font-medium leading-relaxed mb-8 line-clamp-2">
                  {card.description}
                </p>

                {/* Criteria Bar */}
                <div className="grid grid-cols-2 gap-4 mb-8 pt-6 border-t border-white/5">
                   {card.stats.map((stat, idx) => (
                     <div key={idx}>
                        <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">{stat.label}</p>
                        <p className="text-sm font-black text-white">{stat.value}</p>
                     </div>
                   ))}
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setSelectedApplication(card)}
                    className="flex-grow py-4 rounded-xl bg-white text-black text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all shadow-xl shadow-white/5"
                  >
                    Official Application
                  </button>
                  <button className="size-12 rounded-xl bg-white/5 border border-white/5 flex items-center justify-center text-slate-500 hover:text-white transition-all">
                    <span className="material-symbols-outlined text-xl">favorite</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredCards.length === 0 && (
          <div className="text-center py-40 bg-white/5 rounded-[64px] border border-white/5 border-dashed">
             <span className="material-symbols-outlined text-6xl text-slate-700 mb-6">search_off</span>
             <h3 className="text-2xl font-black text-slate-500 tracking-tight">No official {activeType.toLowerCase()} cards found for {activeBank}.</h3>
             <p className="text-slate-600 mt-2 font-medium">Try checking other bank partners or adjusting your search.</p>
          </div>
        )}
      </div>

      {/* Official Application Detail Modal */}
      {selectedApplication && (
        <ApplicationDetailModal 
          card={selectedApplication} 
          onClose={() => setSelectedApplication(null)} 
        />
      )}

      {/* Global Comparison CTA */}
      <div className="max-w-[1440px] mx-auto px-8 mt-32">
         <div className="p-16 lg:p-24 bg-gradient-to-br from-[#1258e2] to-[#002855] rounded-[80px] shadow-[0_64px_160px_-40px_rgba(18,88,226,0.6)] relative overflow-hidden group">
            <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=market')] opacity-5 mix-blend-overlay"></div>
            <div className="relative z-10 flex flex-col lg:flex-row items-center gap-16">
               <div className="shrink-0 size-48 lg:size-64 rounded-[48px] bg-white/10 backdrop-blur-2xl border border-white/20 flex items-center justify-center shadow-2xl group-hover:rotate-6 transition-transform">
                  <span className="material-symbols-outlined text-7xl lg:text-9xl text-white">compare_arrows</span>
               </div>
               <div className="text-center lg:text-left">
                  <h2 className="text-5xl lg:text-7xl font-black text-white tracking-tighter mb-8 leading-none">
                     Not sure which <br/>
                     <span className="opacity-60">bank to trust?</span>
                  </h2>
                  <p className="text-xl text-white/80 max-w-2xl font-medium leading-relaxed mb-12">
                     Compare up to 4 credit and debit cards side-by-side. Our AI-driven logic identifies the hidden fees and reward caps across {BANKS.slice(0, 3).join(', ')} and more.
                  </p>
                  <div className="flex flex-wrap justify-center lg:justify-start gap-6">
                     <button className="px-12 py-6 rounded-2xl bg-white text-primary font-black text-[11px] uppercase tracking-[0.3em] shadow-2xl hover:scale-105 transition-all">
                        Launch Global Comparison
                     </button>
                     <button className="px-12 py-6 rounded-2xl bg-white/10 border border-white/20 text-white font-black text-[11px] uppercase tracking-[0.3em] hover:bg-white/20 transition-all">
                        View Ranking Tables
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default CardGallery;
