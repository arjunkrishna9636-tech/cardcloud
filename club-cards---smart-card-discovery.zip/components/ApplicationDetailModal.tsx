
import React from 'react';
import { CreditCard } from '../types';
import RealisticCard from './RealisticCard';

interface ApplicationDetailModalProps {
  card: CreditCard;
  onClose: () => void;
}

const ApplicationDetailModal: React.FC<ApplicationDetailModalProps> = ({ card, onClose }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/90 backdrop-blur-xl animate-in fade-in duration-500"
        onClick={onClose}
      ></div>
      
      {/* Modal Container */}
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#101622] rounded-[48px] border border-white/10 shadow-[0_64px_128px_-32px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col animate-in zoom-in-95 duration-500">
        
        {/* Decorative background Elements */}
        <div className={`absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br ${card.color} opacity-10 blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none`}></div>
        
        {/* Header */}
        <div className="flex justify-between items-center p-8 md:p-12 border-b border-white/5 relative z-10 shrink-0">
          <div className="flex items-center gap-6">
             <div className="size-14 rounded-2xl bg-white/5 flex items-center justify-center text-primary border border-white/10">
                <span className="material-symbols-outlined text-3xl">verified_user</span>
             </div>
             <div>
                <h2 className="text-3xl font-black text-white tracking-tight">Official Application Gateway</h2>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-1">Instrument ID: {card.id.toUpperCase()}</p>
             </div>
          </div>
          <button 
            onClick={onClose}
            className="size-12 flex items-center justify-center rounded-2xl bg-white/5 text-slate-500 hover:text-white transition-all"
          >
            <span className="material-symbols-outlined text-3xl">close</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-grow overflow-y-auto scrollbar-hide p-8 md:p-12">
          <div className="grid lg:grid-cols-2 gap-16">
            
            {/* Visual Column */}
            <div className="space-y-10">
               <div className="perspective-[1000px] group">
                  <RealisticCard card={card} className="group-hover:-translate-y-4 transition-transform duration-700 shadow-2xl" />
               </div>

               <div className="bg-white/5 border border-white/5 rounded-[32px] p-8">
                  <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-8">Official Fee Structure</h3>
                  <div className="space-y-6">
                     <div className="flex justify-between items-center pb-4 border-b border-white/5">
                        <span className="text-sm font-bold text-slate-400">Joining Fee</span>
                        <span className="text-xl font-black text-white">{card.joiningFee}</span>
                     </div>
                     <div className="flex justify-between items-center pb-4 border-b border-white/5">
                        <span className="text-sm font-bold text-slate-400">Annual/Renewal Fee</span>
                        <span className="text-xl font-black text-white">{card.annualFee}</span>
                     </div>
                     <div className="flex justify-between items-center">
                        <span className="text-sm font-bold text-slate-400">Monthly Maintenance</span>
                        <span className="text-xl font-black text-emerald-400">₹0 <span className="text-[10px] uppercase font-bold text-slate-600 ml-1">Included</span></span>
                     </div>
                  </div>
               </div>

               <div className="p-8 bg-primary/5 border border-primary/10 rounded-[32px]">
                  <div className="flex items-center gap-3 mb-4 text-primary">
                    <span className="material-symbols-outlined">info</span>
                    <span className="text-[10px] font-black uppercase tracking-widest">Club Cards Official Statement</span>
                  </div>
                  <p className="text-sm text-slate-400 font-medium leading-relaxed italic">
                    "This {card.type.toLowerCase()} instrument from <span className="text-white font-bold">{card.issuer}</span> has been verified for high-velocity reward yield and professional financial stability. We recommend this for users looking to optimize their <span className="text-white font-bold">{card.category}</span> portfolio."
                  </p>
               </div>
            </div>

            {/* Information Column */}
            <div className="space-y-12">
               <div>
                  <div className="inline-flex px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[9px] font-black uppercase tracking-widest mb-4 border border-emerald-500/20">
                     Active Partner Offer
                  </div>
                  <h3 className="text-4xl font-black text-white tracking-tighter mb-4 leading-none">{card.name}</h3>
                  <p className="text-lg text-slate-400 font-medium leading-relaxed">
                    {card.description}
                  </p>
               </div>

               <div className="space-y-6">
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Key Privileges</h4>
                  <div className="grid gap-4">
                     {card.detailedBenefits ? card.detailedBenefits.map((benefit, i) => (
                       <div key={i} className="flex gap-5 items-start p-6 bg-white/5 border border-white/5 rounded-3xl group hover:border-primary/30 transition-all">
                          <div className="size-12 rounded-2xl bg-white/5 flex items-center justify-center text-primary shrink-0">
                             <span className="material-symbols-outlined text-2xl">{benefit.icon}</span>
                          </div>
                          <div>
                             <p className="text-sm font-black text-white group-hover:text-primary transition-colors">{benefit.title}</p>
                             <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">{benefit.desc}</p>
                          </div>
                       </div>
                     )) : (
                       <div className="p-10 border border-white/5 border-dashed rounded-3xl text-center">
                          <p className="text-xs text-slate-600 font-medium uppercase tracking-widest">Detailed benefits for this card are currently being synced from {card.issuer} master directions.</p>
                       </div>
                     )}
                  </div>
               </div>

               <div className="pt-8 border-t border-white/5">
                  <div className="flex items-center gap-3 mb-8">
                     <span className="material-symbols-outlined text-emerald-400">check_circle</span>
                     <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Official Bank Application Portal Enabled</p>
                  </div>
                  <div className="flex gap-4">
                     <button className="flex-grow py-5 rounded-2xl bg-primary text-white font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all">
                        Complete Official Application
                     </button>
                     <button className="px-8 py-5 rounded-2xl bg-white/5 border border-white/5 text-slate-500 hover:text-white transition-all">
                        <span className="material-symbols-outlined">share</span>
                     </button>
                  </div>
               </div>
            </div>

          </div>
        </div>

        {/* Footer Bar */}
        <div className="p-6 bg-black/40 border-t border-white/5 text-center shrink-0">
           <p className="text-[9px] font-black text-slate-700 uppercase tracking-[0.5em]">Secure Gateway • PCI-DSS v4.0 Compliant • Verified by Club Cards</p>
        </div>
      </div>
    </div>
  );
};

export default ApplicationDetailModal;
