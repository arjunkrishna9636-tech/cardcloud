
import React, { useState, useEffect } from 'react';

interface LoanDetail {
  type: string;
  bank: string;
  amount: string;
  emi: string;
  status: 'Active' | 'Pending' | 'Closed';
}

const CreditScore: React.FC = () => {
  const [isVerifying, setIsVerifying] = useState(true);
  const [verificationStep, setVerificationStep] = useState(0);
  const [score, setScore] = useState(0);
  const [showData, setShowData] = useState(false);

  const verificationMessages = [
    "Establishing Secure Connection to TransUnion CIBIL...",
    "Retrieving PAN-linked Financial Records...",
    "Syncing with 42 Lending Partners...",
    "Analyzing Ongoing EMIs and Payment History...",
    "Calculating Real-time Credit Strength Index..."
  ];

  const ongoingLoans: LoanDetail[] = [
    { type: 'Personal Loan', bank: 'HDFC BANK', amount: '₹4,50,000', emi: '₹12,450', status: 'Active' },
    { type: 'Auto Loan', bank: 'ICICI BANK', amount: '₹12,00,000', emi: '₹22,800', status: 'Active' },
    { type: 'Consumer Durable', bank: 'AXIS BANK', amount: '₹45,000', emi: '₹4,500', status: 'Closed' }
  ];

  useEffect(() => {
    if (isVerifying) {
      const interval = setInterval(() => {
        setVerificationStep(s => {
          if (s < verificationMessages.length - 1) return s + 1;
          clearInterval(interval);
          setTimeout(() => {
            setIsVerifying(false);
            animateScore(788);
          }, 1000);
          return s;
        });
      }, 1200);
      return () => clearInterval(interval);
    }
  }, [isVerifying]);

  const animateScore = (target: number) => {
    let start = 300;
    const duration = 2000;
    const startTime = performance.now();

    const update = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
      setScore(Math.floor(start + (target - start) * eased));
      
      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        setShowData(true);
      }
    };
    requestAnimationFrame(update);
  };

  const handleRefresh = () => {
    setIsVerifying(true);
    setVerificationStep(0);
    setScore(0);
    setShowData(false);
  };

  if (isVerifying) {
    return (
      <div className="min-h-screen bg-[#0a0f18] flex flex-col items-center justify-center p-6 animate-in fade-in duration-1000">
        <div className="relative size-64 mb-16">
          <div className="absolute inset-0 border-[3px] border-primary/10 rounded-full"></div>
          <div className="absolute inset-0 border-[3px] border-primary border-t-transparent rounded-full animate-[spin_2s_linear_infinite]"></div>
          <div className="absolute inset-4 border-[1px] border-primary/20 rounded-full border-dashed animate-[spin_10s_linear_infinite_reverse]"></div>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
             <span className="material-symbols-outlined text-6xl text-primary animate-pulse mb-2">fingerprint</span>
             <span className="text-[10px] font-black text-primary uppercase tracking-[0.4em]">Verifying Identity</span>
          </div>
        </div>
        
        <div className="max-w-md w-full text-center space-y-6">
           <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-1000 ease-in-out" 
                style={{ width: `${((verificationStep + 1) / verificationMessages.length) * 100}%` }}
              ></div>
           </div>
           <p className="text-xl font-black text-white tracking-tight animate-in slide-in-from-bottom-2 duration-500 key={verificationStep}">
             {verificationMessages[verificationStep]}
           </p>
           <div className="flex justify-center gap-4 text-[10px] font-black text-slate-600 uppercase tracking-widest">
              <span className="flex items-center gap-1"><span className="size-1.5 rounded-full bg-emerald-500 animate-ping"></span> Bureau Live</span>
              <span className="flex items-center gap-1"><span className="size-1.5 rounded-full bg-emerald-500 animate-ping"></span> AES-256</span>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-1000">
      <div className="max-w-[1440px] mx-auto">
        
        {/* Header Branding */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-10">
          <div className="max-w-2xl">
            <div className="flex items-center gap-3 mb-6 text-primary">
              <span className="material-symbols-outlined">verified</span>
              <span className="text-[10px] font-black uppercase tracking-[0.5em]">Real-Time Bureau Analysis</span>
            </div>
            <h1 className="text-6xl lg:text-8xl font-black tracking-tighter mb-6 leading-none">
              Financial <br/><span className="text-primary italic">DNA Report.</span>
            </h1>
            <p className="text-xl text-slate-400 font-medium leading-relaxed">
              Your identity is verified. We've mapped your entire lending ecosystem including <span className="text-white italic">active EMIs</span> and <span className="text-white italic">credit utilization</span>.
            </p>
          </div>
          <button 
            onClick={handleRefresh}
            className="group flex items-center gap-3 px-8 py-4 rounded-2xl bg-white/5 border border-white/10 text-[11px] font-black uppercase tracking-[0.2em] hover:bg-primary hover:text-white transition-all shadow-2xl"
          >
            <span className="material-symbols-outlined text-lg group-hover:rotate-180 transition-transform duration-700">sync</span>
            Re-Sync Bureau Data
          </button>
        </div>

        {/* Main Score Visualizer */}
        <div className="grid lg:grid-cols-12 gap-12 items-stretch mb-24">
          <div className="lg:col-span-8 bg-gradient-to-br from-[#151b27] to-[#0a0f18] border border-white/5 rounded-[64px] p-12 lg:p-24 flex flex-col items-center justify-center relative overflow-hidden shadow-[0_48px_120px_-30px_rgba(0,0,0,0.8)]">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_#1258e215_0%,_transparent_60%)]"></div>
            
            <div className="relative size-[350px] lg:size-[450px] flex items-center justify-center">
              <svg className="absolute inset-0 size-full -rotate-90 drop-shadow-[0_0_50px_rgba(18,88,226,0.3)]">
                <circle cx="50%" cy="50%" r="44%" fill="transparent" stroke="#1c2331" strokeWidth="20" strokeLinecap="round" />
                <circle
                  cx="50%"
                  cy="50%"
                  r="44%"
                  fill="transparent"
                  stroke="url(#scoreGradient)"
                  strokeWidth="20"
                  strokeDasharray="100%"
                  strokeDashoffset={`${100 - ((score - 300) / 600) * 100}%`}
                  className="transition-all duration-300 ease-out"
                  strokeLinecap="round"
                />
                <defs>
                  <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#1258e2" />
                    <stop offset="100%" stopColor="#60a5fa" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="text-center z-10">
                <span className="text-[11px] font-black text-slate-500 uppercase tracking-[0.6em] mb-4 block">CIBIL Score</span>
                <h2 className="text-9xl lg:text-[160px] font-black tracking-tighter leading-none mb-6 drop-shadow-2xl">{score}</h2>
                <div className="px-8 py-3 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-black uppercase tracking-[0.3em] inline-flex items-center gap-3">
                   <span className="size-2 rounded-full bg-emerald-400 animate-pulse"></span>
                   Excellent Profile
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 w-full mt-20 pt-16 border-t border-white/5 gap-12 text-center">
               <div>
                  <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2">On-Time Payments</p>
                  <p className="text-3xl font-black text-white">100%</p>
               </div>
               <div className="border-x border-white/5">
                  <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2">Credit Age</p>
                  <p className="text-3xl font-black text-white">8.4 Yrs</p>
               </div>
               <div>
                  <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2">Limit Utilization</p>
                  <p className="text-3xl font-black text-primary">12%</p>
               </div>
            </div>
          </div>

          {/* Side Insight Panel */}
          <div className="lg:col-span-4 flex flex-col gap-10">
            <div className="bg-primary border border-primary/20 rounded-[48px] p-12 shadow-2xl relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:scale-150 transition-transform duration-1000"></div>
               <h3 className="text-3xl font-black mb-6 leading-tight tracking-tight text-white">Elite Privilege <br/>Unlocked.</h3>
               <p className="text-white/80 font-medium leading-relaxed mb-10">
                 A score of {score} qualifies you for <span className="text-white font-bold italic">Zero-Processing-Fee</span> Home Loans and 0.5% lower ROI across 5 major banks.
               </p>
               <button className="w-full py-5 rounded-2xl bg-white text-primary font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
                 View Partner Offers
               </button>
            </div>

            <div className="bg-[#151b27] border border-white/5 rounded-[48px] p-10 flex-grow shadow-2xl flex flex-col justify-center">
               <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-10">Active EMI Overview</h4>
               <div className="space-y-6">
                  {ongoingLoans.map((loan, i) => (
                    <div key={i} className="flex justify-between items-center p-5 rounded-3xl bg-white/5 border border-white/5 group hover:bg-white/10 transition-all">
                       <div className="flex items-center gap-4">
                          <div className={`size-10 rounded-xl flex items-center justify-center ${loan.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-500/10 text-slate-500'}`}>
                             <span className="material-symbols-outlined text-xl">{loan.type === 'Auto Loan' ? 'directions_car' : 'payments'}</span>
                          </div>
                          <div>
                             <p className="text-sm font-black text-white">{loan.type}</p>
                             <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{loan.bank}</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-sm font-black text-white">{loan.emi}</p>
                          <p className="text-[9px] text-slate-600 font-black uppercase">Monthly EMI</p>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>

        {/* Detailed Financial Footprint */}
        <div className="grid lg:grid-cols-2 gap-12 mb-24">
           <div className="bg-[#151b27]/60 border border-white/5 rounded-[56px] p-12 lg:p-20 shadow-2xl relative overflow-hidden">
              <h3 className="text-3xl font-black mb-10 flex items-center gap-4">
                <span className="material-symbols-outlined text-primary text-4xl">account_tree</span>
                Loan Exposure Details
              </h3>
              <div className="space-y-10">
                 <div className="flex justify-between items-end">
                    <div>
                       <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Total Sanctioned Limit</p>
                       <p className="text-5xl font-black">₹42,50,000</p>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-2">Available Headroom</p>
                       <p className="text-2xl font-black text-emerald-400">₹32,45,200</p>
                    </div>
                 </div>
                 <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-primary shadow-[0_0_15px_rgba(18,88,226,0.6)]" style={{ width: '24%' }}></div>
                 </div>
                 <div className="grid grid-cols-2 gap-8 pt-8 border-t border-white/5">
                    <div>
                       <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1">Secured Debt</p>
                       <p className="text-xl font-black">₹12,00,000</p>
                    </div>
                    <div>
                       <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1">Unsecured Debt</p>
                       <p className="text-xl font-black text-orange-400">₹4,50,000</p>
                    </div>
                 </div>
              </div>
           </div>

           <div className="bg-[#151b27]/60 border border-white/5 rounded-[56px] p-12 lg:p-20 shadow-2xl">
              <h3 className="text-3xl font-black mb-10 flex items-center gap-4">
                <span className="material-symbols-outlined text-primary text-4xl">insights</span>
                Strategic Score Benefits
              </h3>
              <div className="space-y-8">
                 {[
                   { title: 'Credit Multiplier', desc: 'You are eligible for card limits up to 10x your monthly income.', icon: 'trending_up', color: 'text-blue-400' },
                   { title: 'Global Recognition', desc: 'Your high score simplifies verification for international visa and forex products.', icon: 'public', color: 'text-purple-400' },
                   { title: 'Interest Leverage', desc: 'Saves approximately ₹4,200/month on current loan interest via ROI reduction.', icon: 'savings', color: 'text-emerald-400' }
                 ].map((benefit, i) => (
                    <div key={i} className="flex gap-6 items-start group cursor-default">
                       <div className={`size-12 rounded-2xl bg-white/5 flex items-center justify-center ${benefit.color} border border-white/5 shrink-0 group-hover:scale-110 transition-transform shadow-xl`}>
                          <span className="material-symbols-outlined text-2xl">{benefit.icon}</span>
                       </div>
                       <div>
                          <h4 className="text-lg font-black mb-1 group-hover:text-primary transition-colors">{benefit.title}</h4>
                          <p className="text-sm text-slate-500 font-medium leading-relaxed">{benefit.desc}</p>
                       </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>

        {/* Global Footer Quote */}
        <div className="p-20 bg-gradient-to-br from-[#1258e2] to-[#002855] rounded-[80px] text-center shadow-[0_64px_160px_-40px_rgba(18,88,226,0.6)] relative overflow-hidden">
           <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=cibil')] opacity-5 mix-blend-overlay"></div>
           <div className="relative z-10">
              <h2 className="text-5xl font-black mb-8 leading-none tracking-tighter">Your Financial Legacy Starts with a Number.</h2>
              <p className="text-xl text-white/80 max-w-2xl mx-auto font-medium leading-relaxed mb-12">
                A high CIBIL score is more than just a number—it's your <span className="text-white font-bold italic underline underline-offset-8 decoration-white/30">purchasing power</span>. Manage it with discipline and unlock the lifestyle you deserve.
              </p>
              <button className="px-16 py-6 rounded-[24px] bg-white text-primary font-black text-[11px] uppercase tracking-[0.4em] shadow-2xl hover:scale-105 active:scale-95 transition-all">
                 Download Comprehensive CIBIL Audit
              </button>
           </div>
        </div>

      </div>
    </div>
  );
};

export default CreditScore;
