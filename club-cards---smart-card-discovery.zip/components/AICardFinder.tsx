
import React, { useState, useRef, useEffect } from 'react';
import { getCardRecommendation } from '../services/geminiService';
import { CreditCard } from '../types';
// Fix: Import ALL_CARDS instead of non-existent FEATURED_CARDS
import { ALL_CARDS } from '../constants';

const AICardFinder: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ card: CreditCard; reason: string } | null>(null);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (chatRef.current && !chatRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleRecommend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    setLoading(true);
    setResult(null);
    
    const recommendation = await getCardRecommendation(input);
    
    if (recommendation && recommendation.cardId) {
      // Fix: Use ALL_CARDS to find the recommended card details
      const card = ALL_CARDS.find(c => c.id === recommendation.cardId);
      if (card) {
        setResult({ card, reason: recommendation.reason });
      }
    }
    setLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100]" ref={chatRef}>
      {isOpen ? (
        <div className="w-80 sm:w-96 bg-surface-dark border border-border-dark rounded-xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom-4 duration-300">
          <div className="p-4 bg-primary text-white flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined">auto_awesome</span>
              <span className="font-bold">Smart Card Finder</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 rounded-full p-1 transition-colors">
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>

          <div className="p-4 h-96 overflow-y-auto bg-[#0b0e14]">
            {result ? (
              <div className="space-y-4 animate-in fade-in duration-500">
                <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                  <p className="text-xs text-primary font-bold mb-2 uppercase">AI Recommendation</p>
                  <p className="text-sm text-slate-300 italic mb-4">"{result.reason}"</p>
                  
                  <div className="flex gap-3 items-center">
                    <div className={`h-12 w-20 rounded bg-gradient-to-br ${result.card.color} border border-white/10 flex items-center justify-center`}>
                      <span className="text-[10px] text-white/50">{result.card.issuer}</span>
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm">{result.card.name}</p>
                      <p className="text-slate-500 text-xs">{result.card.rewards}</p>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => setResult(null)}
                  className="w-full py-2 text-sm text-primary font-bold hover:bg-primary/5 rounded transition-colors"
                >
                  Try another search
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                <div className="size-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined" style={{ fontSize: '32px' }}>psychology</span>
                </div>
                <div>
                  <h4 className="text-white font-bold">Ask AI Anything</h4>
                  <p className="text-xs text-slate-500 mt-1">Tell me about your lifestyle, spending, or travel goals and I'll find your perfect card match.</p>
                </div>
                <div className="flex flex-wrap justify-center gap-2">
                  <button 
                    onClick={() => setInput('I travel to Europe 4 times a year and spend mostly on dining.')}
                    className="text-[10px] bg-border-dark hover:bg-primary/20 hover:text-primary text-slate-400 px-3 py-1 rounded-full transition-all"
                  >
                    "I travel to Europe often..."
                  </button>
                  <button 
                    onClick={() => setInput('I want a card for grocery shopping and everyday cashback.')}
                    className="text-[10px] bg-border-dark hover:bg-primary/20 hover:text-primary text-slate-400 px-3 py-1 rounded-full transition-all"
                  >
                    "Grocery and cashback..."
                  </button>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleRecommend} className="p-4 border-t border-border-dark">
            <div className="relative">
              <input 
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Describe your spending..."
                className="w-full bg-border-dark border-none rounded-lg py-2 pl-4 pr-12 text-sm text-white placeholder:text-slate-600 focus:ring-1 focus:ring-primary transition-all"
                disabled={loading}
              />
              <button 
                type="submit"
                disabled={loading || !input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-primary hover:text-blue-400 disabled:text-slate-700 transition-colors"
              >
                {loading ? (
                  <span className="material-symbols-outlined animate-spin">refresh</span>
                ) : (
                  <span className="material-symbols-outlined">send</span>
                )}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="size-14 rounded-full bg-primary text-white shadow-2xl shadow-primary/40 flex items-center justify-center hover:scale-110 active:scale-95 transition-all group overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
          <span className="material-symbols-outlined relative z-10" style={{ fontSize: '28px' }}>auto_awesome</span>
        </button>
      )}
    </div>
  );
};

export default AICardFinder;
