
import React, { useState } from 'react';

interface CuratedCardsProps {
  userData?: {
    income: number;
    employment: string;
    tenure: string;
    focus: string;
  };
}

const CuratedCards: React.FC<CuratedCardsProps> = ({ userData }) => {
  const [activeFilter, setActiveFilter] = useState('All Cards');

  const income = userData?.income || 100000;
  const focus = userData?.focus || 'Travel & Dining';

  const filters = ['All Cards', 'Elite Tier', 'Stability First', 'High Yield'];

  const recommendations = [
    {
      id: 'sapphire-elite',
      name: 'Sapphire Reserve Elite',
      issuer: 'CLUB CARDS',
      type: 'Metal Card • Visa Infinite',
      match: '98%',
      reason: `Optimized for ₹${income.toLocaleString()} monthly income. High tenure stability ensures easy approval for this premium travel instrument.`,
      benefits: [
        '3x Points on Global Lifestyle',
        '₹25,000 Annual Stability Credit',
        'Emergency Buffer Protection'
      ],
      fee: '₹45,000',
      color: 'bg-gradient-to-br from-blue-600 to-blue-900',
      isTop: true
    },
    {
      id: 'platinum-stability',
      name: 'Platinum Stability Plus',
      issuer: 'PLATINUM',
      type: 'Financial Continuity • Global Buffer',
      match: '94%',
      reason: `Based on your goal of '${focus}', this card acts as a safety net while building long-term credit history.`,
      benefits: [
        '0% APR Balance Transfers',
        'Utility Cash Reserve',
        'Professional Concierge'
      ],
      fee: '₹12,000',
      color: 'bg-[#1c1f27]',
      isTop: false
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1200px] mx-auto">
        
        {/* Header Section */}
        <div className="mb-12">
          <h1 className="text-5xl font-black tracking-tight mb-4 leading-none">Your Personalized Recommendations</h1>
          <p className="text-slate-400 text-lg max-w-2xl font-medium">
            Analyzed for <span className="text-white">Financial Stability</span> and long-term asset management. These cards match your ₹{income.toLocaleString()} income bracket.
          </p>
        </div>

        {/* Profile Breakdown */}
        <div className="bg-[#151b27] border border-white/5 rounded-[40px] p-10 mb-12 shadow-2xl relative overflow-hidden group">
          <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-all duration-700 pointer-events-none"></div>
          <div className="flex justify-between items-center mb-10 relative">
            <div>
              <h3 className="text-xl font-black mb-1">Financial Profile Summary</h3>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Calculated Stability Factors</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-[#0a0f18]/40 border border-white/5 rounded-3xl p-8 hover:border-primary/30 transition-all group/stat">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Lender Score</p>
              <p className="text-4xl font-black text-white group-hover/stat:text-primary transition-colors">A+</p>
              <p className="text-xs text-slate-600 font-bold mt-2">Stability Confirmed</p>
            </div>

            <div className="bg-[#0a0f18]/40 border border-white/5 rounded-3xl p-8 hover:border-primary/30 transition-all group/stat">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Monthly Liquid</p>
              <p className="text-4xl font-black text-white group-hover/stat:text-primary transition-colors">₹{income.toLocaleString()}</p>
              <p className="text-xs text-slate-600 font-bold mt-2">Executive Bracket</p>
            </div>

            <div className="bg-[#0a0f18]/40 border border-white/5 rounded-3xl p-8 hover:border-primary/30 transition-all group/stat">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Strategic Focus</p>
              <p className="text-4xl font-black text-white group-hover/stat:text-primary transition-colors truncate">{focus}</p>
              <p className="text-xs text-slate-600 font-bold mt-2">Continuity: {userData?.tenure || 'Stable'}</p>
            </div>
          </div>
        </div>

        {/* Recommendations List */}
        <div className="space-y-10">
          {recommendations.map(card => (
            <div key={card.id} className="bg-[#151b27]/60 border border-white/5 rounded-[48px] overflow-hidden hover:border-white/10 transition-all p-2 group shadow-2xl">
              <div className="p-10 flex flex-col lg:flex-row gap-12">
                
                {/* Visual */}
                <div className="w-full lg:w-[420px] shrink-0">
                  <div className={`relative aspect-[1.586] rounded-[32px] overflow-hidden shadow-2xl transition-transform duration-700 group-hover:scale-[1.03] ${card.color}`}>
                     <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=lux')] opacity-5 mix-blend-overlay"></div>
                     <div className="relative p-10 h-full flex flex-col justify-between">
                        <div className="flex justify-between items-start">
                           <span className="text-white/40 text-[10px] font-black tracking-[0.4em] uppercase">{card.issuer}</span>
                           <span className="material-symbols-outlined text-white/20 text-3xl">contactless</span>
                        </div>
                        <div>
                           <div className="size-12 rounded-xl border border-white/10 bg-white/5 mb-6"></div>
                           <p className="text-white font-black text-lg tracking-tight uppercase leading-none">{card.name}</p>
                        </div>
                     </div>
                  </div>
                  {card.isTop && (
                    <div className="mt-6 flex justify-center">
                      <div className="flex items-center gap-3 px-6 py-2 rounded-full bg-primary/10 text-primary font-black text-[10px] uppercase tracking-widest border border-primary/20">
                        <span className="material-symbols-outlined text-sm">verified</span>
                        Strategic Fit Confirmed
                      </div>
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-grow flex flex-col">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <h2 className="text-4xl font-black mb-2 tracking-tight">{card.name}</h2>
                      <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">{card.type}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-primary font-black text-2xl tracking-tighter">{card.match} MATCH</p>
                    </div>
                  </div>

                  <div className="bg-[#0a0f18]/60 border border-white/5 rounded-[24px] p-6 mb-10 flex items-start gap-5 border-l-4 border-l-primary group-hover:bg-[#0a0f18]/80 transition-all">
                    <span className="material-symbols-outlined text-primary text-2xl">auto_awesome</span>
                    <p className="text-sm text-slate-300 leading-relaxed font-medium">
                      "{card.reason}"
                    </p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-8 mb-12">
                    {card.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <span className="material-symbols-outlined text-emerald-400 text-2xl">check_circle</span>
                        <span className="text-sm font-bold text-slate-300">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-auto pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
                    <div className="flex flex-col">
                      <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.3em] mb-1">Financial Access Fee</span>
                      <span className="text-2xl font-black text-white">{card.fee} <span className="text-sm text-slate-500 font-bold">/ YEAR</span></span>
                    </div>
                    <div className="flex items-center gap-6 w-full md:w-auto">
                      <button className="text-[10px] font-black text-slate-500 uppercase tracking-widest hover:text-white transition-colors">Compare Eligibility</button>
                      <button className="flex-1 md:flex-none bg-primary hover:bg-blue-600 transition-all px-10 py-4 rounded-[20px] font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl shadow-primary/30">
                        Start Application
                        <span className="material-symbols-outlined text-sm">arrow_forward</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24 p-12 bg-white/5 rounded-[40px] border border-white/5 text-center">
           <h4 className="text-xl font-black mb-4">Why Stability Matters</h4>
           <p className="text-sm text-slate-500 max-w-2xl mx-auto font-medium leading-relaxed">
              Choosing the right card is about more than just rewards; it's about <span className="text-white">Financial Resilience</span>. A card with a lower APR and higher limit provides a safety buffer during utility fluctuations, ensuring your lifestyle remains abroad or local without compromise.
           </p>
        </div>
      </div>
    </div>
  );
};

export default CuratedCards;
