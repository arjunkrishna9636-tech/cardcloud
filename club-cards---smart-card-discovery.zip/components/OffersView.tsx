
import React, { useState } from 'react';

type OfferCategory = 'All' | 'Shopping' | 'Food' | 'Travel' | 'Vouchers';

interface Offer {
  id: string;
  brand: string;
  title: string;
  category: OfferCategory;
  discount: string;
  expiry: string;
  applicableCards: string[];
  icon: string;
  color: string;
}

const OFFERS_DATA: Offer[] = [
  {
    id: '1',
    brand: 'Amazon',
    title: 'E-Gift Voucher',
    category: 'Vouchers',
    discount: '₹500 OFF',
    expiry: 'Valid for 30 days',
    applicableCards: ['Sapphire Reserve', 'Amex Platinum'],
    icon: 'redeem',
    color: 'bg-orange-500/10 text-orange-400'
  },
  {
    id: '2',
    brand: 'Zomato',
    title: 'Gourmet Dining',
    category: 'Food',
    discount: '50% OFF',
    expiry: 'Ends in 2 days',
    applicableCards: ['Gold Rewards', 'SavorOne'],
    icon: 'restaurant',
    color: 'bg-red-500/10 text-red-400'
  },
  {
    id: '3',
    brand: 'MakeMyTrip',
    title: 'International Flights',
    category: 'Travel',
    discount: 'Up to ₹10,000 OFF',
    expiry: 'Limited Time',
    applicableCards: ['Sapphire Reserve', 'Venture X'],
    icon: 'flight_takeoff',
    color: 'bg-blue-500/10 text-blue-400'
  },
  {
    id: '4',
    brand: 'Apple Store',
    title: 'MacBook & iPhone',
    category: 'Shopping',
    discount: '₹6,000 Instant Disc.',
    expiry: 'Festive Offer',
    applicableCards: ['Amex Platinum', 'HDFC Regalia'],
    icon: 'laptop_mac',
    color: 'bg-slate-500/10 text-slate-300'
  },
  {
    id: '5',
    brand: 'Starbucks',
    title: 'BOGO Offer',
    category: 'Food',
    discount: 'Buy 1 Get 1',
    expiry: 'Weekends only',
    applicableCards: ['Any Lux Card'],
    icon: 'local_cafe',
    color: 'bg-emerald-500/10 text-emerald-400'
  },
  {
    id: '6',
    brand: 'Marriott Bonvoy',
    title: 'Luxury Stay',
    category: 'Travel',
    discount: '3rd Night Free',
    expiry: 'Select Properties',
    applicableCards: ['Amex Platinum'],
    icon: 'hotel',
    color: 'bg-purple-500/10 text-purple-400'
  }
];

const OffersView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<OfferCategory>('All');

  const filteredOffers = activeTab === 'All' 
    ? OFFERS_DATA 
    : OFFERS_DATA.filter(o => o.category === activeTab);

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1200px] mx-auto">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4 text-primary">
              <span className="material-symbols-outlined">local_activity</span>
              <span className="text-[10px] font-black uppercase tracking-[0.4em]">Exclusive Card Perks</span>
            </div>
            <h1 className="text-5xl font-black tracking-tight mb-4 leading-none">Vouchers & Offers</h1>
            <p className="text-slate-400 text-lg max-w-xl font-medium">
              Maximize your <span className="text-white">Financial Strength</span> with curated lifestyle benefits from our global partners.
            </p>
          </div>
          
          <div className="flex p-1.5 bg-white/5 rounded-2xl border border-white/5 backdrop-blur-xl">
            {(['All', 'Shopping', 'Food', 'Travel', 'Vouchers'] as OfferCategory[]).map(tab => (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-slate-500 hover:text-white'}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Offers Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredOffers.map((offer) => (
            <div key={offer.id} className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-8 group hover:border-primary/20 transition-all shadow-2xl flex flex-col relative overflow-hidden">
              <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                 <span className="material-symbols-outlined text-7xl">{offer.icon}</span>
              </div>
              
              <div className="flex items-center justify-between mb-8">
                <div className={`size-14 rounded-2xl flex items-center justify-center ${offer.color} border border-white/5 shadow-inner`}>
                   <span className="material-symbols-outlined text-3xl">{offer.icon}</span>
                </div>
                <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">{offer.category}</span>
              </div>

              <div className="mb-8">
                <h3 className="text-sm font-black text-slate-500 uppercase tracking-widest mb-1">{offer.brand}</h3>
                <h2 className="text-2xl font-black mb-2 tracking-tight group-hover:text-primary transition-colors">{offer.title}</h2>
                <div className="text-3xl font-black text-white">{offer.discount}</div>
              </div>

              <div className="space-y-4 mb-10">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                   <span className="material-symbols-outlined text-sm">schedule</span>
                   {offer.expiry}
                </div>
                <div className="pt-4 border-t border-white/5">
                  <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Applicable on:</p>
                  <div className="flex flex-wrap gap-2">
                    {offer.applicableCards.map((card, idx) => (
                      <span key={idx} className="px-2 py-1 rounded bg-white/5 text-[9px] font-black text-slate-400 border border-white/5">
                        {card}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <button className="mt-auto w-full py-4 rounded-2xl bg-white/5 border border-white/5 text-xs font-black uppercase tracking-widest text-slate-400 group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-all shadow-xl">
                Claim Offer
              </button>
            </div>
          ))}
        </div>

        {/* Guide Prompt */}
        <div className="mt-20 p-12 bg-white/5 rounded-[48px] border border-white/5 flex flex-col md:flex-row items-center gap-10">
           <div className="size-24 rounded-3xl bg-primary/10 flex items-center justify-center text-primary shrink-0 shadow-2xl">
              <span className="material-symbols-outlined text-5xl">auto_awesome</span>
           </div>
           <div>
              <h4 className="text-2xl font-black mb-2">Want better offers?</h4>
              <p className="text-slate-400 font-medium leading-relaxed max-w-2xl">
                 Based on your current <span className="text-white">stability report</span>, upgrading to an Elite card could unlock premium 1-for-1 dining vouchers and complimentary global lounge visits.
              </p>
           </div>
           <button className="md:ml-auto px-10 py-5 rounded-2xl bg-primary text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/30 hover:scale-105 transition-all">
              Analyze Eligibility
           </button>
        </div>
      </div>
    </div>
  );
};

export default OffersView;
