
import React, { useState } from 'react';
import { ALL_CARDS } from '../constants';
import RealisticCard from './RealisticCard';
import { CreditCard } from '../types';

type ComparisonType = 'Credit vs Credit' | 'Credit vs Debit' | 'Custom Audit';

const CardComparison: React.FC = () => {
  const [activeMode, setActiveMode] = useState<ComparisonType>('Credit vs Credit');
  const [selectedCards, setSelectedCards] = useState<CreditCard[]>(ALL_CARDS.slice(0, 2));
  const [userScore, setUserScore] = useState(750);

  // Strength calculation logic for professional UI
  const getStrengthMetric = (card: CreditCard) => {
    const feeValue = parseInt(card.fee.replace(/\D/g, '')) || 0;
    if (feeValue === 0) return 94; // LTF cards are high strength
    if (feeValue > 10000) return 88; // Luxury cards have high prestige strength
    return 75;
  };

  const toggleCard = (card: CreditCard) => {
    if (selectedCards.find(c => c.id === card.id)) {
      setSelectedCards(selectedCards.filter(c => c.id !== card.id));
    } else if (selectedCards.length < 3) {
      setSelectedCards([...selectedCards, card]);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0f18] pb-32 animate-in fade-in duration-700">
      {/* Premium Header Section */}
      <div className="relative pt-24 pb-20 overflow-hidden border-b border-white/5 bg-gradient-to-b from-[#0f172a] to-[#0a0f18]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,_#1258e210_0%,_transparent_50%)]"></div>
        <div className="max-w-[1440px] mx-auto px-8 w-full relative z-10">
          <div className="flex flex-col lg:flex-row justify-between items-end gap-12">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-[10px] font-black uppercase tracking-[0.4em] mb-6 border border-primary/20">
                <span className="material-symbols-outlined text-sm">analytics</span>
                Club Cards Comparison Engine v4.0
              </div>
              <h1 className="text-6xl lg:text-[100px] font-black text-white tracking-tighter mb-8 leading-[0.85]">
                Systematic <br/>
                <span className="text-primary italic">Audit.</span>
              </h1>
              <p className="text-xl text-slate-400 font-medium leading-relaxed max-w-xl">
                Our proprietary comparison logic analyzes instruments side-by-side to determine your <span className="text-white">Credit Score Capability</span> and the exact moment you should buy.
              </p>
            </div>

            <div className="flex bg-white/5 p-2 rounded-[32px] border border-white/10 backdrop-blur-xl">
              {(['Credit vs Credit', 'Credit vs Debit', 'Custom Audit'] as ComparisonType[]).map(mode => (
                <button 
                  key={mode}
                  onClick={() => setActiveMode(mode)}
                  className={`px-8 py-4 rounded-[24px] text-[11px] font-black uppercase tracking-widest transition-all ${activeMode === mode ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-8 mt-16">
        <div className="grid lg:grid-cols-12 gap-12">
          
          {/* LEFT: Comparison Grid */}
          <div className="lg:col-span-8 space-y-12">
            
            {/* The Comparison Table */}
            <div className="bg-[#151b27]/60 border border-white/5 rounded-[64px] overflow-hidden shadow-2xl backdrop-blur-3xl">
              <div className="grid grid-cols-1 md:grid-cols-3 divide-x divide-white/5">
                
                {/* Metric Labels Column */}
                <div className="hidden md:flex flex-col pt-12">
                   <div className="h-[280px] p-10 flex flex-col justify-end">
                      <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Instrument Specs</span>
                   </div>
                   {[
                     { label: 'Buying Strength', icon: 'bolt' },
                     { label: 'Score Capability', icon: 'speed' },
                     { label: 'Joining Fee', icon: 'payments' },
                     { label: 'Benefit Profile', icon: 'award_star' },
                     { label: 'Network ROI', icon: 'trending_up' }
                   ].map((metric, i) => (
                     <div key={i} className="p-10 border-t border-white/5 flex items-center gap-4">
                        <span className="material-symbols-outlined text-slate-700 text-xl">{metric.icon}</span>
                        <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{metric.label}</span>
                     </div>
                   ))}
                </div>

                {/* Selected Cards Columns */}
                {selectedCards.map((card, i) => (
                  <div key={card.id} className={`flex flex-col transition-all duration-700 ${i === 0 ? 'bg-primary/5' : ''}`}>
                    <div className="p-10 border-b border-white/5 h-[280px] flex flex-col justify-between group">
                       <RealisticCard card={card} showDetails={false} className="h-40 group-hover:-translate-y-2 transition-transform shadow-2xl" />
                       <div className="mt-6">
                          <h3 className="text-lg font-black text-white">{card.name}</h3>
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{card.issuer}</p>
                       </div>
                    </div>

                    {/* Metric: Strength */}
                    <div className="p-10 border-b border-white/5 flex flex-col justify-center gap-4">
                       <div className="flex justify-between items-end">
                          <span className="text-3xl font-black text-white">{getStrengthMetric(card)}%</span>
                          <span className="text-[9px] font-black text-slate-600 uppercase">Yield Rating</span>
                       </div>
                       <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div className={`h-full bg-primary rounded-full transition-all duration-1000`} style={{ width: `${getStrengthMetric(card)}%` }}></div>
                       </div>
                    </div>

                    {/* Metric: Capability */}
                    <div className="p-10 border-b border-white/5">
                       <p className="text-sm font-black text-white mb-2">Excellent</p>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-relaxed">
                         Requires {userScore > 700 ? 'No verification' : 'Strict audit'}
                       </p>
                    </div>

                    {/* Metric: Fee */}
                    <div className="p-10 border-b border-white/5">
                       <p className="text-2xl font-black text-white">{card.joiningFee}</p>
                       <p className="text-[9px] text-slate-600 font-black uppercase mt-1">One-time entry</p>
                    </div>

                    {/* Metric: Benefits */}
                    <div className="p-10 border-b border-white/5">
                       <div className="flex flex-wrap gap-2">
                          {card.stats.slice(0, 2).map((s, idx) => (
                            <span key={idx} className="px-3 py-1 rounded-lg bg-white/5 border border-white/5 text-[9px] font-black uppercase text-slate-400">
                               {s.label}
                            </span>
                          ))}
                       </div>
                    </div>

                    {/* Action */}
                    <div className="p-10">
                       <button className={`w-full py-5 rounded-2xl font-black text-[11px] uppercase tracking-widest transition-all ${i === 0 ? 'bg-primary text-white shadow-xl shadow-primary/20 hover:scale-[1.02]' : 'bg-white/5 text-slate-400 border border-white/10 hover:bg-white/10 hover:text-white'}`}>
                          Buy Instrument Now
                       </button>
                    </div>
                  </div>
                ))}

                {/* Add Card Placeholder if less than 3 */}
                {selectedCards.length < 2 && (
                  <div className="p-20 flex flex-col items-center justify-center text-center group cursor-pointer hover:bg-white/5 transition-colors border-dashed border-2 border-white/5 rounded-r-[64px]">
                     <div className="size-20 rounded-full bg-white/5 flex items-center justify-center text-slate-700 group-hover:text-primary group-hover:bg-primary/10 transition-all mb-8">
                        <span className="material-symbols-outlined text-4xl">add</span>
                     </div>
                     <p className="text-lg font-black text-slate-600">Add Comparison</p>
                  </div>
                )}

              </div>
            </div>

            {/* Strategic Summary Panel */}
            <div className="bg-gradient-to-br from-[#1258e2] to-[#002855] rounded-[64px] p-16 shadow-2xl relative overflow-hidden group">
               <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=audit')] opacity-5 mix-blend-overlay"></div>
               <div className="relative z-10 grid md:grid-cols-2 gap-16 items-center">
                  <div>
                     <div className="flex items-center gap-3 mb-6 text-white/60">
                        <span className="material-symbols-outlined">lightbulb</span>
                        <span className="text-[10px] font-black uppercase tracking-widest">Buy Recommendation</span>
                     </div>
                     <h2 className="text-4xl font-black text-white mb-6 leading-tight">Which one should you buy right now?</h2>
                     <p className="text-lg text-white/80 font-medium leading-relaxed mb-10">
                        Based on your current <span className="text-white font-bold underline decoration-white/30 underline-offset-4">Score Capability ({userScore})</span>, we recommend the <span className="text-white font-bold">{selectedCards[0]?.name}</span>. It offers a 12% higher ROI on utility spends compared to the other options.
                     </p>
                     <div className="flex gap-6">
                        <button className="px-10 py-5 rounded-2xl bg-white text-primary font-black text-[11px] uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
                           Proceed to Buy
                        </button>
                     </div>
                  </div>
                  <div className="bg-black/20 backdrop-blur-xl border border-white/10 rounded-[48px] p-12">
                     <p className="text-[11px] font-black text-white/40 uppercase tracking-[0.4em] mb-10 text-center">Capability Strength Index</p>
                     <div className="flex justify-center mb-10">
                        <div className="relative size-48">
                           <svg className="size-full -rotate-90">
                              <circle cx="50%" cy="50%" r="42%" fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="12" />
                              <circle cx="50%" cy="50%" r="42%" fill="transparent" stroke="white" strokeWidth="12" strokeDasharray="100%" strokeDashoffset="15%" strokeLinecap="round" />
                           </svg>
                           <div className="absolute inset-0 flex flex-col items-center justify-center">
                              <span className="text-5xl font-black text-white">85</span>
                              <span className="text-[9px] font-black text-white/40 uppercase">Optimal</span>
                           </div>
                        </div>
                     </div>
                     <p className="text-xs text-white/60 text-center font-medium leading-relaxed">
                        Your profile stability allows for high-limit instruments without additional collateral.
                     </p>
                  </div>
               </div>
            </div>
          </div>

          {/* RIGHT: Audit Tools & Library */}
          <div className="lg:col-span-4 space-y-10">
             
             {/* Score Capability Tool */}
             <div className="bg-[#151b27] border border-white/5 rounded-[48px] p-12 shadow-2xl">
                <h3 className="text-2xl font-black mb-8 flex items-center gap-4">
                   <span className="material-symbols-outlined text-primary">speed</span>
                   Score Capability
                </h3>
                <p className="text-sm text-slate-500 font-medium leading-relaxed mb-10">
                   Input your CIBIL score to see which cards you are <span className="text-white">Pre-Approved</span> for right now.
                </p>
                <div className="space-y-12">
                   <div>
                      <div className="flex justify-between mb-4">
                         <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Active Bureau Score</span>
                         <span className="text-lg font-black text-primary">{userScore}</span>
                      </div>
                      <input 
                        type="range" min="300" max="900" value={userScore}
                        onChange={(e) => setUserScore(parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary"
                      />
                   </div>
                   <div className="grid grid-cols-2 gap-6">
                      <div className="p-6 rounded-3xl bg-white/5 border border-white/5 text-center">
                         <p className="text-xl font-black text-white">82%</p>
                         <p className="text-[9px] text-slate-600 font-black uppercase mt-1">Approval Chance</p>
                      </div>
                      <div className="p-6 rounded-3xl bg-white/5 border border-white/5 text-center">
                         <p className="text-xl font-black text-emerald-400">Elite</p>
                         <p className="text-[9px] text-slate-600 font-black uppercase mt-1">Status Class</p>
                      </div>
                   </div>
                </div>
             </div>

             {/* Review Catalog Sidebar */}
             <div className="bg-[#151b27]/60 border border-white/5 rounded-[48px] p-12 shadow-2xl">
                <h3 className="text-xl font-black mb-10">Systematic Library</h3>
                <div className="space-y-6">
                   {ALL_CARDS.slice(0, 5).map(card => (
                     <div 
                      key={card.id}
                      onClick={() => toggleCard(card)}
                      className={`flex items-center gap-5 p-5 rounded-3xl border transition-all cursor-pointer group ${selectedCards.find(c => c.id === card.id) ? 'bg-primary/10 border-primary/40 shadow-lg' : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
                     >
                        <div className={`size-12 rounded-2xl bg-gradient-to-br ${card.color} flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform`}>
                           <span className="material-symbols-outlined text-white/50 text-xl">{card.icon}</span>
                        </div>
                        <div className="flex-grow">
                           <p className="text-sm font-black text-white">{card.name}</p>
                           <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{card.issuer}</p>
                        </div>
                        <span className="material-symbols-outlined text-slate-700">
                           {selectedCards.find(c => c.id === card.id) ? 'check_circle' : 'add_circle'}
                        </span>
                     </div>
                   ))}
                </div>
                <button className="w-full mt-10 py-4 rounded-xl border border-white/5 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:text-white transition-all">
                   Browse Full Review Catalog
                </button>
             </div>

             {/* Comparison Philosophy */}
             <div className="p-10 bg-primary/5 border border-primary/10 rounded-[48px] shadow-inner">
                <h4 className="text-sm font-black mb-4 uppercase tracking-[0.2em] text-primary flex items-center gap-2">
                   <span className="material-symbols-outlined text-lg">verified_user</span>
                   Our Comparison Ethos
                </h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed italic">
                   "We don't just compare rewards. We audit the underlying <span className="text-white">stability requirements</span> of each instrument to ensure your portfolio remains resilient abroad or local."
                </p>
             </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default CardComparison;
