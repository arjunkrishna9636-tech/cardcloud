
import React from 'react';
import { CreditCard, CardFinish } from '../types';

interface RealisticCardProps {
  card: CreditCard;
  className?: string;
  showDetails?: boolean;
}

const RealisticCard: React.FC<RealisticCardProps> = ({ card, className = '', showDetails = true }) => {
  const getFinishStyles = (finish: CardFinish) => {
    switch (finish) {
      case 'obsidian':
        return {
          container: 'bg-black shadow-[0_30px_60px_rgba(0,0,0,0.8)]',
          texture: 'bg-[url("https://www.transparenttextures.com/patterns/carbon-fibre.png")] opacity-5',
          glare: 'bg-gradient-to-tr from-white/10 via-transparent to-white/5',
          text: 'text-slate-400',
          accent: 'border-slate-800/50',
          foil: 'bg-gradient-to-r from-slate-400 to-slate-100 bg-clip-text text-transparent'
        };
      case 'matte-black':
        return {
          container: 'bg-[#0a0a0a] shadow-[0_30px_60px_rgba(0,0,0,0.9)]',
          texture: 'bg-[url("https://www.transparenttextures.com/patterns/pinstriped-suit.png")] opacity-10',
          glare: 'bg-gradient-to-tr from-white/5 via-transparent to-white/5',
          text: 'text-zinc-500',
          accent: 'border-zinc-800',
          foil: 'text-zinc-300 font-bold'
        };
      case 'titanium':
        return {
          container: 'bg-slate-200 shadow-[0_30px_60px_rgba(148,163,184,0.3)]',
          texture: 'bg-[url("https://www.transparenttextures.com/patterns/brushed-alum.png")] opacity-30',
          glare: 'bg-gradient-to-tr from-white/40 via-transparent to-black/5',
          text: 'text-slate-600',
          accent: 'border-slate-400/20',
          foil: 'text-slate-900 font-black'
        };
      case 'gold':
        return {
          container: 'bg-[#f0c808] shadow-[0_30px_60px_rgba(234,179,8,0.3)]',
          texture: 'bg-[url("https://www.transparenttextures.com/patterns/gold-tips.png")] opacity-20',
          glare: 'bg-gradient-to-tr from-white/40 via-transparent to-amber-900/20',
          text: 'text-amber-950/60',
          accent: 'border-amber-700/20',
          foil: 'text-amber-950 font-black'
        };
      case 'pearl':
        return {
          container: 'bg-slate-50 shadow-[0_30px_60px_rgba(255,255,255,0.1)]',
          texture: 'bg-[url("https://www.transparenttextures.com/patterns/white-diamond.png")] opacity-10',
          glare: 'bg-gradient-to-tr from-blue-100/30 via-transparent to-rose-100/30',
          text: 'text-slate-400',
          accent: 'border-slate-200',
          foil: 'bg-gradient-to-r from-slate-700 to-slate-950 bg-clip-text text-transparent font-bold'
        };
      case 'cobalt':
        return {
          container: 'bg-indigo-950 shadow-[0_30px_60px_rgba(30,58,138,0.4)]',
          texture: 'bg-[url("https://www.transparenttextures.com/patterns/dark-matter.png")] opacity-20',
          glare: 'bg-gradient-to-tr from-white/10 via-transparent to-blue-400/10',
          text: 'text-indigo-400',
          accent: 'border-indigo-800',
          foil: 'text-white font-black'
        };
      default:
        return {
          container: 'bg-slate-900',
          texture: '',
          glare: '',
          text: 'text-white/60',
          accent: 'border-white/10',
          foil: 'text-white'
        };
    }
  };

  const styles = getFinishStyles(card.finish);

  return (
    <div className={`relative aspect-[1.586] w-full rounded-[24px] overflow-hidden transition-all duration-700 group ${styles.container} ${className}`}>
      {/* Texture Layer */}
      <div className={`absolute inset-0 ${styles.texture} mix-blend-overlay pointer-events-none`}></div>
      
      {/* Glare/Shine Layer */}
      <div className={`absolute inset-0 ${styles.glare} pointer-events-none`}></div>

      {/* Real Card Content */}
      <div className="relative z-10 p-10 h-full flex flex-col justify-between">
        <div className="flex justify-between items-start">
          <div className="flex flex-col">
            <span className={`text-[10px] font-black tracking-[0.4em] uppercase ${styles.text}`}>
              {card.issuer}
            </span>
            <span className={`text-xl font-black tracking-tighter uppercase leading-none mt-2 ${styles.foil}`}>
              {card.name}
            </span>
          </div>
          {/* Bank Logo / Icon Placeholder */}
          <div className={`size-10 rounded-full flex items-center justify-center border ${styles.accent} ${styles.text}`}>
            <span className="material-symbols-outlined text-xl">account_balance</span>
          </div>
        </div>

        <div>
          {/* High-Resolution EMV Chip Visual */}
          <div className="mb-8 relative w-14 h-10 group-hover:scale-110 transition-transform">
            <div className="absolute inset-0 bg-gradient-to-br from-[#ffd700] via-[#ffec8b] to-[#b8860b] rounded-md border border-[#8b7d6b]/30 shadow-inner"></div>
            {/* Chip Logic Lines */}
            <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-40">
              <div className="border-r border-b border-black/40"></div>
              <div className="border-r border-b border-black/40"></div>
              <div className="border-b border-black/40"></div>
              <div className="border-r border-b border-black/40"></div>
              <div className="border-r border-b border-black/40"></div>
              <div className="border-b border-black/40"></div>
              <div className="border-r border-black/40"></div>
              <div className="border-r border-black/40"></div>
              <div></div>
            </div>
          </div>

          {showDetails && (
            <div className="flex justify-between items-end">
              <div>
                <p className={`text-[10px] font-mono tracking-[0.3em] mb-2 opacity-50 ${styles.text}`}>
                  **** **** **** {Math.floor(1000 + Math.random() * 9000)}
                </p>
                <div className="flex flex-col">
                  <p className={`text-[8px] uppercase tracking-widest opacity-40 font-black ${styles.text}`}>Card Holder</p>
                  <p className={`text-[11px] font-black uppercase tracking-widest ${styles.text}`}>CLUB CARDS MEMBER</p>
                </div>
              </div>
              <div className="flex flex-col items-end">
                {/* Network Logos */}
                <div className="flex gap-1.5 mb-2">
                   <div className={`size-4 rounded-full ${styles.text} bg-current opacity-40`}></div>
                   <div className={`size-4 rounded-full ${styles.text} bg-current opacity-20`}></div>
                </div>
                <span className={`text-[10px] font-black italic tracking-tighter opacity-40 ${styles.text}`}>
                  VISA PLATINUM
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Security Hologram */}
      <div className="absolute bottom-10 right-10 size-12 rounded-full bg-gradient-to-tr from-blue-400/20 via-purple-400/20 to-rose-400/20 backdrop-blur-md border border-white/5 flex items-center justify-center opacity-40 group-hover:opacity-100 transition-opacity">
        <span className={`material-symbols-outlined text-[18px] ${styles.text}`}>verified</span>
      </div>
    </div>
  );
};

export default RealisticCard;
