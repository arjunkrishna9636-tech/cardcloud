
import React, { useState } from 'react';

const LoansView: React.FC = () => {
  const [income, setIncome] = useState(45000);
  const [tenure, setTenure] = useState(3); // Years

  const maxLoanAmount = (income * 0.4 * 60); // Simple 40% DTI over 5 years
  const stabilityIndex = tenure > 2 ? 'High' : 'Medium';

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1200px] mx-auto">
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4 text-primary">
            <span className="material-symbols-outlined">handshake</span>
            <span className="text-[10px] font-black uppercase tracking-[0.4em]">Financial Strength Analyzer</span>
          </div>
          <h1 className="text-5xl font-black tracking-tight mb-4 leading-none">Smart Loan Discovery</h1>
          <p className="text-slate-400 text-lg max-w-2xl font-medium">
            Based on your monthly income of <span className="text-white">₹{income.toLocaleString()}</span> and career stability.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 space-y-8">
            {/* Analyzer Tool */}
            <div className="bg-[#151b27] border border-white/5 rounded-[40px] p-10 shadow-2xl relative overflow-hidden">
               <div className="grid md:grid-cols-2 gap-12 mb-10">
                  <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Adjust Your Monthly Income</p>
                    <input 
                      type="range" 
                      min="15000" 
                      max="300000" 
                      step="5000"
                      value={income}
                      onChange={(e) => setIncome(parseInt(e.target.value))}
                      className="w-full h-2 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary mb-6"
                    />
                    <div className="bg-[#0a0f18]/40 border border-white/5 p-6 rounded-2xl text-center">
                       <p className="text-3xl font-black text-white">₹{income.toLocaleString()}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Current Job Stability (Years)</p>
                    <div className="flex justify-between gap-4">
                       {[1, 2, 3, 5, 10].map(y => (
                         <button 
                          key={y}
                          onClick={() => setTenure(y)}
                          className={`flex-1 py-4 rounded-xl border text-xs font-black transition-all ${tenure === y ? 'bg-primary border-primary text-white shadow-lg shadow-primary/20' : 'bg-white/5 border-white/5 text-slate-500 hover:text-white'}`}
                         >
                           {y}Y
                         </button>
                       ))}
                    </div>
                  </div>
               </div>

               <div className="border-t border-white/5 pt-10 flex flex-col md:flex-row justify-between items-center gap-8">
                  <div className="text-center md:text-left">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Max Eligible Loan Amount</p>
                    <p className="text-5xl font-black text-emerald-400">₹{maxLoanAmount.toLocaleString()}</p>
                  </div>
                  <div className="text-center md:text-right">
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Stability Rating</p>
                    <p className={`text-2xl font-black ${tenure > 2 ? 'text-blue-400' : 'text-orange-400'}`}>{stabilityIndex} Profile</p>
                  </div>
               </div>
            </div>

            {/* Loan Options */}
            <div className="space-y-6">
               <h3 className="text-xl font-black">Eligible Loan Products</h3>
               {[
                 { name: 'Personal Growth Loan', rate: '10.5%', type: 'Unsecured', limit: 'Up to ₹25L', icon: 'person' },
                 { name: 'Elite Home Finance', rate: '8.4%', type: 'Secured', limit: 'Up to ₹5Cr', icon: 'home' },
                 { name: 'Business Expansion Line', rate: '12.0%', type: 'Enterprise', limit: 'Up to ₹1Cr', icon: 'business_center' },
               ].map((loan, idx) => (
                 <div key={idx} className="bg-[#151b27]/60 border border-white/5 rounded-3xl p-8 flex items-center justify-between group hover:border-white/10 transition-all">
                    <div className="flex items-center gap-6">
                       <div className="size-14 rounded-2xl bg-white/5 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                          <span className="material-symbols-outlined text-3xl">{loan.icon}</span>
                       </div>
                       <div>
                          <p className="text-lg font-black">{loan.name}</p>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">{loan.type} • {loan.limit}</p>
                       </div>
                    </div>
                    <div className="text-right">
                       <p className="text-xl font-black text-primary">{loan.rate}</p>
                       <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest">Fixed APR</p>
                    </div>
                 </div>
               ))}
            </div>
          </div>

          <div className="lg:col-span-4 space-y-8">
             <div className="bg-primary/10 border border-primary/20 rounded-[40px] p-8">
                <h4 className="text-lg font-black mb-4">Financial Guidance</h4>
                <p className="text-sm text-slate-400 leading-relaxed font-medium mb-8">
                   Based on your <span className="text-white font-bold">{stabilityIndex} stability</span>, we recommend maintaining a loan-to-income ratio below 35% to ensure long-term wealth Abroad or Local.
                </p>
                <div className="space-y-4">
                   <div className="flex items-center gap-3">
                      <span className="material-symbols-outlined text-primary text-sm">verified</span>
                      <span className="text-xs font-bold text-slate-300">Guaranteed Lowest Rates</span>
                   </div>
                   <div className="flex items-center gap-3">
                      <span className="material-symbols-outlined text-primary text-sm">verified</span>
                      <span className="text-xs font-bold text-slate-300">No Prepayment Charges</span>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoansView;
