
import React, { useState } from 'react';

type WalletSubView = 'wallet' | 'discover' | 'analytics' | 'transactions';

const MyWallet: React.FC = () => {
  const [currentSubView, setCurrentSubView] = useState<WalletSubView>('wallet');
  const [selectedCardId, setSelectedCardId] = useState('sapphire-pref');

  const myCards = [
    {
      id: 'sapphire-pref',
      name: 'Sapphire Preferred',
      number: '4242',
      issuer: 'HDFC BANK',
      color: 'bg-gradient-to-br from-blue-700 to-blue-900',
      brand: 'VISA',
      balance: 1240.50,
      limit: 10000,
      apr: '18.24%',
      points: '45,230',
      nextClosing: 'Nov 12',
      lastPayment: '₹42,000'
    },
    {
      id: 'gold-rewards',
      name: 'Gold Rewards',
      number: '8821',
      issuer: 'AMEX',
      color: 'bg-gradient-to-br from-yellow-700 to-amber-900',
      brand: 'MASTERCARD',
      balance: 450.00,
      limit: 5000,
      apr: '21.00%',
      points: '12,100',
      nextClosing: 'Nov 15',
      lastPayment: '₹8,500'
    },
    {
      id: 'platinum-edge',
      name: 'Platinum Edge',
      number: '9900',
      issuer: 'ICICI BANK',
      color: 'bg-gradient-to-br from-slate-700 to-slate-900',
      brand: 'VISA',
      balance: 0,
      limit: 25000,
      apr: '16.50%',
      points: '89,400',
      nextClosing: 'Nov 22',
      lastPayment: '₹1,20,000'
    }
  ];

  const transactions = [
    { id: 'tx1', merchant: 'Apple Store', product: 'iPhone 15 Pro', location: 'Mumbai, IN', date: '24 Oct 2024', time: '14:20', amount: '₹1,34,900', method: 'Credit Card', upi: 'none', category: 'Shopping', status: 'Success', icon: 'laptop_mac' },
    { id: 'tx2', merchant: 'Starbucks', product: 'Vanilla Latte', location: 'Delhi, IN', date: '24 Oct 2024', time: '09:15', amount: '₹450', method: 'UPI', upi: 'alex@axisbank', category: 'Food', status: 'Success', icon: 'local_cafe' },
    { id: 'tx3', merchant: 'MakeMyTrip', product: 'Flight: DEL to DXB', location: 'Online', date: '23 Oct 2024', time: '22:10', amount: '₹22,400', method: 'Credit Card', upi: 'none', category: 'Travel', status: 'Success', icon: 'flight' },
    { id: 'tx4', merchant: 'Zomato', product: 'Gourmet Meal', location: 'Bangalore, IN', date: '23 Oct 2024', time: '20:00', amount: '₹1,200', method: 'UPI', upi: 'alex@hdfc', category: 'Food', status: 'Success', icon: 'restaurant' },
    { id: 'tx5', merchant: 'Amazon', product: 'Kindle Scribe', location: 'Online', date: '22 Oct 2024', time: '11:45', amount: '₹28,000', method: 'Credit Card', upi: 'none', category: 'Shopping', status: 'Pending', icon: 'shopping_bag' },
    { id: 'tx6', merchant: 'Indigo', product: 'Travel Voucher', location: 'Online', date: '21 Oct 2024', time: '16:30', amount: '₹5,000', method: 'Debit Card', upi: 'none', category: 'Travel', status: 'Success', icon: 'confirmation_number' },
  ];

  const selectedCard = myCards.find(c => c.id === selectedCardId) || myCards[0];
  const utilization = Math.round((selectedCard.balance / selectedCard.limit) * 100);

  return (
    <div className="flex h-[calc(100vh-80px)] bg-[#0a0f18] text-white overflow-hidden animate-in fade-in duration-500">
      {/* Premium Sidebar */}
      <aside className="w-80 border-r border-white/5 bg-[#0a0f18] flex flex-col p-8 shrink-0">
        <div className="mb-12">
           <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-4 ml-4">Management</p>
           <nav className="space-y-2">
            {[
              { id: 'wallet', label: 'My Wallet', icon: 'wallet' },
              { id: 'discover', label: 'Discover', icon: 'explore' },
              { id: 'analytics', label: 'Analytics', icon: 'analytics' },
              { id: 'transactions', label: 'Transactions', icon: 'receipt_long' },
            ].map((item) => (
              <button 
                key={item.id}
                onClick={() => setCurrentSubView(item.id as WalletSubView)}
                className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-sm transition-all ${currentSubView === item.id ? 'bg-primary text-white shadow-xl shadow-primary/20' : 'text-slate-500 hover:bg-white/5 hover:text-white'}`}
              >
                <span className="material-symbols-outlined">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto space-y-4 pt-8 border-t border-white/5">
          <div className="bg-white/5 rounded-3xl p-6 border border-white/5">
             <div className="flex items-center gap-3 mb-4">
                <span className="material-symbols-outlined text-emerald-400">verified_user</span>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security Active</span>
             </div>
             <p className="text-xs text-slate-500 leading-relaxed font-medium">Your wallet is protected by AES-256 encryption & Club Cards protocol.</p>
          </div>
          
          <div className="flex items-center gap-4 px-4 py-2 group cursor-pointer">
            <div className="size-11 rounded-full bg-slate-700 overflow-hidden ring-2 ring-white/10 group-hover:ring-primary transition-all">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" alt="Avatar" />
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-black truncate">Alex Morgan</p>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest truncate">alex.member@clubcards.in</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-grow overflow-y-auto p-12 scrollbar-hide">
        <div className="max-w-6xl mx-auto">
          
          {/* VIEW: MY WALLET */}
          {currentSubView === 'wallet' && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
               <div className="flex justify-between items-center mb-10">
                <div>
                  <h1 className="text-4xl font-black tracking-tight mb-2">My Card Wallet</h1>
                  <p className="text-slate-500 text-sm font-medium">Detailed overview of your banking instruments.</p>
                </div>
                <button className="bg-primary hover:bg-blue-600 px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-3 transition-all shadow-xl shadow-primary/20">
                  <span className="material-symbols-outlined text-lg">add_card</span>
                  Provision Card
                </button>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-12">
                <div className="bg-[#151b27]/60 border border-white/5 rounded-3xl p-8">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Aggregate Limit</p>
                  <p className="text-4xl font-black mb-2">₹42,50,000</p>
                  <p className="text-xs text-emerald-400 font-bold">Strong Liquidity Buffer</p>
                </div>
                <div className="bg-[#151b27]/60 border border-white/5 rounded-3xl p-8">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Total Utilization</p>
                  <p className="text-4xl font-black mb-2">12.4%</p>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full mt-4 overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: '12.4%' }}></div>
                  </div>
                </div>
                <div className="bg-[#151b27]/60 border border-white/5 rounded-3xl p-8">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Active Points Pool</p>
                  <p className="text-4xl font-black text-primary mb-2">1,46,830</p>
                  <p className="text-xs text-slate-500 font-bold">Estimated Value: ₹36,700</p>
                </div>
              </div>

              <div className="mb-12">
                <h2 className="text-xl font-black mb-8 ml-2">Active Instruments</h2>
                <div className="flex gap-6 overflow-x-auto pb-6 scrollbar-hide">
                  {myCards.map(card => (
                    <div 
                      key={card.id}
                      onClick={() => setSelectedCardId(card.id)}
                      className={`min-w-[340px] aspect-[1.586] rounded-3xl p-8 flex flex-col justify-between cursor-pointer transition-all duration-300 relative overflow-hidden ${card.id === selectedCardId ? 'ring-2 ring-primary scale-[1.02] shadow-2xl' : 'opacity-40 hover:opacity-100 border border-white/10'} ${card.color}`}
                    >
                      <div className="absolute inset-0 bg-white/5 opacity-40 mix-blend-overlay"></div>
                      <div className="relative flex justify-between items-start">
                        <div>
                          <p className="text-[10px] font-black tracking-widest mb-1 opacity-60">{card.issuer}</p>
                          <p className="text-xl font-black tracking-tight">{card.name}</p>
                        </div>
                        <span className="material-symbols-outlined opacity-60">contactless</span>
                      </div>
                      <div className="relative">
                        <p className="text-xl font-mono tracking-[0.4em] mb-1">•••• {card.number}</p>
                        <p className="text-[10px] font-black uppercase opacity-60">{card.brand} PRIVILEGE</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* VIEW: DISCOVER */}
          {currentSubView === 'discover' && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-700">
              <div className="mb-12">
                <h1 className="text-4xl font-black tracking-tight mb-2">Intelligence Feed</h1>
                <p className="text-slate-500 text-sm font-medium">Real-time market discovery and card rotation strategies.</p>
              </div>

              <div className="grid lg:grid-cols-2 gap-8 mb-12">
                <div className="bg-gradient-to-br from-primary/20 to-blue-900/10 border border-primary/20 rounded-[40px] p-10 relative overflow-hidden group">
                   <div className="relative z-10">
                      <div className="size-14 rounded-2xl bg-primary flex items-center justify-center text-white mb-8 shadow-xl">
                        <span className="material-symbols-outlined text-3xl">insights</span>
                      </div>
                      <h3 className="text-3xl font-black mb-4">Strategic Rotation</h3>
                      <p className="text-slate-400 font-medium leading-relaxed mb-10 max-w-sm">
                        Based on your upcoming Apple Store transaction, our engine suggests using <span className="text-white font-bold">HDFC Infinia</span> for an extra 5x reward point acceleration.
                      </p>
                      <button className="px-8 py-3.5 rounded-2xl bg-white text-primary font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 transition-all">
                        Enable Auto-Route
                      </button>
                   </div>
                   <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[80px] group-hover:bg-primary/20 transition-all duration-700"></div>
                </div>

                <div className="bg-[#151b27] border border-white/5 rounded-[40px] p-10 group overflow-hidden">
                   <div className="flex justify-between items-start mb-10">
                      <div>
                        <h3 className="text-2xl font-black mb-1">Market Pulse</h3>
                        <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Global Rewards Tracker</p>
                      </div>
                      <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[9px] font-black uppercase tracking-widest border border-emerald-500/20">Syncing Live</span>
                   </div>
                   <div className="space-y-6">
                      {[
                        { label: 'Travel Yield Index', value: '+4.2%', color: 'text-emerald-400' },
                        { label: 'Forex Volatility', value: 'High', color: 'text-orange-400' },
                        { label: 'Luxury Dining Offers', value: '12 Active', color: 'text-primary' }
                      ].map((stat, i) => (
                        <div key={i} className="flex justify-between items-center p-5 rounded-2xl bg-white/5 border border-white/5">
                           <span className="text-sm font-bold text-slate-300">{stat.label}</span>
                           <span className={`text-sm font-black ${stat.color}`}>{stat.value}</span>
                        </div>
                      ))}
                   </div>
                </div>
              </div>

              <div className="bg-white/5 border border-white/5 rounded-[48px] p-12 text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=discover')] opacity-5 mix-blend-overlay"></div>
                <h2 className="text-3xl font-black mb-6">Discover New Instruments</h2>
                <p className="text-slate-500 max-w-2xl mx-auto font-medium leading-relaxed mb-10">
                  Our system analyzed your current 12.4% utilization. You are eligible for an <span className="text-white">Elite Portfolio Expansion</span> with HSBC Premier.
                </p>
                <button className="px-12 py-5 rounded-2xl bg-primary text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-105 transition-all">
                  Browse Eligible Catalog
                </button>
              </div>
            </div>
          )}

          {/* VIEW: ANALYTICS */}
          {currentSubView === 'analytics' && (
            <div className="animate-in fade-in zoom-in-95 duration-700">
               <div className="mb-12">
                <h1 className="text-4xl font-black tracking-tight mb-2">Financial Pulse</h1>
                <p className="text-slate-500 text-sm font-medium">Deep-dive into spending behavior and leakage analysis.</p>
              </div>

              <div className="grid lg:grid-cols-12 gap-10 mb-12">
                <div className="lg:col-span-8 bg-[#151b27] border border-white/5 rounded-[48px] p-12 shadow-2xl">
                   <h3 className="text-xl font-black mb-10 flex items-center gap-4">
                     <span className="material-symbols-outlined text-primary">pie_chart</span>
                     Spending Category Distribution
                   </h3>
                   <div className="space-y-8">
                      {[
                        { label: 'Shopping & Retail', amount: '₹1,62,900', pct: 60, color: 'bg-primary' },
                        { label: 'Travel & Airlines', amount: '₹27,400', pct: 25, color: 'bg-emerald-500' },
                        { label: 'Food & Dining', amount: '₹1,650', pct: 5, color: 'bg-orange-500' },
                        { label: 'Others', amount: '₹12,400', pct: 10, color: 'bg-slate-600' },
                      ].map((item, i) => (
                        <div key={i}>
                           <div className="flex justify-between items-end mb-3">
                              <span className="text-sm font-bold text-slate-300">{item.label}</span>
                              <span className="text-sm font-black">{item.amount} <span className="text-[10px] text-slate-600 ml-1">({item.pct}%)</span></span>
                           </div>
                           <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                              <div className={`h-full ${item.color} rounded-full transition-all duration-[1s]`} style={{ width: `${item.pct}%` }}></div>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>

                <div className="lg:col-span-4 space-y-8">
                   <div className="bg-primary/10 border border-primary/20 rounded-[40px] p-10 text-center">
                      <p className="text-[10px] font-black text-primary uppercase tracking-[0.4em] mb-4">Buying Power Index</p>
                      <h2 className="text-6xl font-black text-white mb-2 tracking-tighter">942</h2>
                      <p className="text-xs text-emerald-400 font-bold uppercase">Elite Status Unlocked</p>
                   </div>
                   <div className="bg-white/5 border border-white/5 rounded-[40px] p-8">
                      <h4 className="text-sm font-black mb-6 uppercase tracking-widest text-slate-400">Yield Optimization</h4>
                      <p className="text-xs text-slate-500 leading-relaxed font-medium mb-8">
                        You could have earned <span className="text-white font-bold">1,240 more points</span> this month by routing Starbucks through Axis MyZone.
                      </p>
                      <button className="w-full py-3.5 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all">
                         View Leakage Map
                      </button>
                   </div>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: TRANSACTIONS (USER CALLED IT TRANSITIONS) */}
          {currentSubView === 'transactions' && (
            <div className="animate-in fade-in slide-in-from-left-4 duration-700">
              <div className="flex justify-between items-end mb-12">
                <div>
                  <h1 className="text-4xl font-black tracking-tight mb-2">Ledger Details</h1>
                  <p className="text-slate-500 text-sm font-medium">Informative and transparent financial transitions.</p>
                </div>
                <div className="flex gap-4">
                   <div className="flex p-1 bg-white/5 rounded-2xl border border-white/5">
                      <button className="px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest bg-primary text-white shadow-lg">Month</button>
                      <button className="px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-500">Quarter</button>
                   </div>
                   <button className="size-11 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center text-slate-500 hover:text-white">
                      <span className="material-symbols-outlined">filter_list</span>
                   </button>
                </div>
              </div>

              <div className="bg-[#151b27]/40 border border-white/5 rounded-[48px] overflow-hidden shadow-2xl">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/5 bg-white/[0.02]">
                       <th className="p-8 text-[10px] font-black text-slate-600 uppercase tracking-widest">Merchant & Product</th>
                       <th className="p-8 text-[10px] font-black text-slate-600 uppercase tracking-widest">Date & Time</th>
                       <th className="p-8 text-[10px] font-black text-slate-600 uppercase tracking-widest">Payment Method</th>
                       <th className="p-8 text-[10px] font-black text-slate-600 uppercase tracking-widest text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx, i) => (
                      <tr key={tx.id} className="border-b border-white/5 hover:bg-white/[0.03] transition-colors group">
                        <td className="p-8">
                           <div className="flex items-center gap-6">
                              <div className="size-12 rounded-2xl bg-white/5 flex items-center justify-center text-primary border border-white/5 group-hover:scale-110 transition-transform">
                                 <span className="material-symbols-outlined">{tx.icon}</span>
                              </div>
                              <div>
                                 <p className="text-sm font-black text-white">{tx.merchant}</p>
                                 <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">
                                   {tx.product} • <span className="text-slate-600">{tx.location}</span>
                                 </p>
                              </div>
                           </div>
                        </td>
                        <td className="p-8">
                           <div className="flex flex-col">
                              <span className="text-sm font-bold text-slate-300">{tx.date}</span>
                              <span className="text-[10px] font-black text-slate-600 mt-1">{tx.time}</span>
                           </div>
                        </td>
                        <td className="p-8">
                           <div className="flex items-center gap-4">
                              <div className="size-8 rounded-xl bg-white/5 flex items-center justify-center text-slate-400">
                                 <span className="material-symbols-outlined text-lg">{tx.method === 'UPI' ? 'qr_code_2' : 'credit_card'}</span>
                              </div>
                              <div>
                                 <p className="text-xs font-black text-slate-300">{tx.method}</p>
                                 {tx.upi !== 'none' && <p className="text-[9px] text-primary font-bold">{tx.upi}</p>}
                              </div>
                           </div>
                        </td>
                        <td className="p-8 text-right">
                           <p className="text-lg font-black text-white">{tx.amount}</p>
                           <span className={`text-[9px] font-black uppercase tracking-[0.2em] ${tx.status === 'Success' ? 'text-emerald-400' : 'text-orange-400 animate-pulse'}`}>
                             {tx.status}
                           </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-12 flex justify-center">
                 <button className="flex items-center gap-3 text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] hover:text-white transition-colors">
                    Load Archive History <span className="material-symbols-outlined text-sm">expand_more</span>
                 </button>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
};

export default MyWallet;
