
import React from 'react';
import { AppView } from '../types';

interface FeaturesProps {
  onStartCompare: () => void;
  onCheckScore: () => void;
  onSeeMatches: () => void;
}

const Features: React.FC<FeaturesProps> = ({ onStartCompare, onCheckScore, onSeeMatches }) => {
  const features = [
    {
      title: 'Compare Cards',
      desc: 'Side-by-side analysis of fees, rewards, and APRs to find the perfect fit for your wallet.',
      icon: 'compare_arrows',
      color: 'blue',
      linkText: 'Start Comparison',
      action: onStartCompare
    },
    {
      title: 'CIBIL Analysis',
      desc: 'High-fidelity credit bureau sync with deep-dive loan tracking and EMI audits.',
      icon: 'speed',
      color: 'emerald',
      linkText: 'Check Bureau Score',
      action: onCheckScore
    },
    {
      title: 'Personalized Recs',
      desc: 'AI-driven suggestions based on your spending habits to maximize your rewards potential.',
      icon: 'auto_awesome',
      color: 'purple',
      linkText: 'See Matches',
      action: onSeeMatches
    }
  ];

  return (
    <section className="py-16 bg-white dark:bg-[#0b0e14] border-y border-gray-100 dark:border-border-dark">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl font-extrabold text-slate-900 dark:text-white mb-4 tracking-tight">Smarter Financial Tools</h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg font-medium">Everything you need to make informed credit decisions in one place. Powerful analytics meets intuitive design.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <div 
              key={i} 
              onClick={feature.action}
              className="group cursor-pointer relative p-10 rounded-[40px] bg-gray-50 dark:bg-surface-dark border border-gray-200 dark:border-border-dark hover:border-primary/50 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/5"
            >
              <div className={`size-14 rounded-2xl bg-${feature.color}-100 dark:bg-${feature.color}-900/30 text-${feature.color}-600 dark:text-${feature.color}-400 flex items-center justify-center mb-10 group-hover:scale-110 transition-transform shadow-sm`}>
                <span className="material-symbols-outlined" style={{ fontSize: '32px' }}>{feature.icon}</span>
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-4 tracking-tight">{feature.title}</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm font-medium leading-relaxed mb-10">{feature.desc}</p>
              <button className="inline-flex items-center text-primary font-black text-[10px] uppercase tracking-widest group-hover:gap-4 transition-all">
                {feature.linkText} <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
