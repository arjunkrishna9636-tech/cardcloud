
import React, { useState } from 'react';
import { ALL_CARDS } from '../constants';

type VerificationMethod = 'pin' | 'cvv';

const MyBenefits: React.FC = () => {
  const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Select, 2: Verify, 3: Active Benefits
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [verifyMethod, setVerifyMethod] = useState<VerificationMethod>('cvv');
  const [pinCode, setPinCode] = useState(['', '', '', '']);
  const [cvvCode, setCvvCode] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isCardFlipped, setIsCardFlipped] = useState(false);

  const selectedCard = ALL_CARDS.find(c => c.id === selectedCardId) || ALL_CARDS[0];

  const handleVerify = () => {
    setIsVerifying(true);
    // Simulate secure banking handshake
    setTimeout(() => {
      setIsVerifying(false);
      setStep(3);
    }, 2500);
  };

  const activePerks = [
    { title: 'Airport Lounge Access', status: 'Active', desc: '4/4 Visits remaining this quarter', icon: 'flight_takeoff', color: 'text-blue-400' },
    { title: 'Reward Multiplier', status: 'Enabled', desc: '5x points on all weekend dining', icon: 'trending_up', color: 'text-emerald-400' },
    { title: 'Concierge Priority', status: 'Premium', desc: 'Live chat support average wait < 1 min', icon: 'support_agent', color: 'text-purple-400' },
    { title: 'Insurance Shield', status: 'Covered', desc: 'Active protection up to ₹25,00,000', icon: 'shield', color: 'text-orange-400' }
  ];

  const pointsBreakdown = [
    { label: 'Travel Redemption', value: '₹10,712', pts: '42,850 pts', rate: '1 pt = ₹0.25' },
    { label: 'Statement Credit', value: '₹4,285', pts: '42,850 pts', rate: '1 pt = ₹0.10' },
    { label: 'Voucher Exchange', value: '₹8,570', pts: '42,850 pts', rate: '1 pt = ₹0.20' }
  ];

  if (isVerifying) {
    return (
      <div className="min-h-screen bg-[#0a0f18] flex items-center justify-center p-8">
        <div className="text-center">
          <div className="relative size-40 mx-auto mb-10">
            <div className="absolute inset-0 border-4 border-primary/10 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="material-symbols-outlined text-5xl text-primary animate-pulse">lock_open</span>
            </div>
          </div>
          <h2 className="text-4xl font-black mb-4 tracking-tight">Syncing Live Benefits</h2>
          <p className="text-slate-500 font-medium text-lg">Communicating with Club Cards Secure Gateway...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1280px] mx-auto">
        
        {step === 1 && (
          <div className="animate-in slide-in-from-bottom-8 duration-700">
            <div className="mb-20 text-center md:text-left">
              <div className="flex items-center gap-3 mb-6 justify-center md:justify-start">
                <span className="text-[10px] font-black uppercase tracking-[0.5em] text-primary">Membership Club</span>
              </div>
              <h1 className="text-6xl lg:text-8xl font-black tracking-tighter mb-8 leading-none">Check My <br/><span className="text-primary italic">Live Benefits.</span></h1>
              <p className="text-xl text-slate-400 max-w-2xl font-medium leading-relaxed">
                Verify your instrument and see exactly what benefits you are eligible for right now based on your current card points.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
              {ALL_CARDS.slice(0, 6).map(card => (
                <div 
                  key={card.id}
                  onClick={() => {
                    setSelectedCardId(card.id);
                    setStep(2);
                  }}
                  className="group relative aspect-[1.58] rounded-[40px] overflow-hidden cursor-pointer transition-all duration-500 border border-white/5 hover:border-primary/50 hover:scale-[1.03] shadow-2xl"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-90 group-hover:opacity-100 transition-opacity`}></div>
                  <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=lux')] opacity-5 mix-blend-overlay"></div>
                  <div className="relative p-10 h-full flex flex-col justify-between">
                    <div className="flex justify-between items-start">
                       <div>
                         <p className="text-[10px] font-black tracking-[0.3em] text-white/50 uppercase mb-1">{card.issuer}</p>
                         <p className="text-2xl font-black text-white tracking-tight">{card.name}</p>
                       </div>
                       <span className="material-symbols-outlined text-white/30 text-3xl">contactless</span>
                    </div>
                    <div className="flex justify-between items-end">
                       <div>
                         <p className="text-xs font-mono text-white/40 tracking-widest mb-4">**** **** **** {Math.floor(1000 + Math.random() * 9000)}</p>
                         <div className="flex items-center gap-2">
                            <span className="px-3 py-1 rounded-full bg-white/10 border border-white/10 text-[9px] font-black uppercase tracking-widest text-white">Check Benefits</span>
                         </div>
                       </div>
                       <div className="size-12 rounded-full bg-white/10 flex items-center justify-center border border-white/10">
                          <span className="material-symbols-outlined text-white/60">arrow_forward</span>
                       </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="max-w-4xl mx-auto animate-in zoom-in-95 duration-700">
            <button onClick={() => setStep(1)} className="flex items-center gap-2 text-slate-500 hover:text-white mb-12 font-black text-xs uppercase tracking-widest transition-colors">
              <span className="material-symbols-outlined text-sm">arrow_back</span>
              Back to Selection
            </button>

            <div className="text-center mb-20">
              <h2 className="text-5xl font-black mb-6 tracking-tight">Security Verification</h2>
              <p className="text-lg text-slate-500 font-medium">For your security, enter your Card PIN or the 3-digit <span className="text-white">Security Code (CVV)</span> from the back.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-16 items-center">
               <div className="perspective-[1000px] h-72 w-full">
                  <div className={`relative w-full h-full transition-all duration-700 preserve-3d cursor-pointer ${isCardFlipped ? 'rotate-y-180' : ''}`} onClick={() => setIsCardFlipped(!isCardFlipped)}>
                    <div className={`absolute inset-0 bg-gradient-to-br ${selectedCard.color} rounded-[40px] p-10 shadow-2xl backface-hidden flex flex-col justify-between border border-white/10`}>
                       <div className="flex justify-between items-start">
                          <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">{selectedCard.issuer}</p>
                          <span className="material-symbols-outlined text-white/30 text-3xl">sensors</span>
                       </div>
                       <div className="w-16 h-12 rounded-lg bg-yellow-500/20 border border-yellow-500/30"></div>
                       <div>
                          <p className="text-2xl font-mono tracking-[0.3em] text-white/90 mb-2">**** **** **** 8842</p>
                          <p className="text-[10px] font-black text-white/30 uppercase tracking-widest">Selected Member Card</p>
                       </div>
                       <div className="absolute bottom-6 right-10 flex items-center gap-2 opacity-50">
                          <span className="text-[10px] font-black uppercase tracking-widest text-white">Click to Flip</span>
                          <span className="material-symbols-outlined text-sm text-white">360</span>
                       </div>
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-950 rounded-[40px] shadow-2xl backface-hidden rotate-y-180 border border-white/10 flex flex-col overflow-hidden">
                       <div className="h-14 w-full bg-black mt-10"></div>
                       <div className="px-10 mt-10 flex items-center gap-6">
                          <div className="flex-grow h-12 bg-white/5 rounded-lg flex items-center px-4 font-mono text-white/20 text-xs italic border border-white/5">AUTHORIZED SIGNATURE</div>
                          <div className="w-24 h-12 bg-white flex items-center justify-center rounded-lg text-black font-mono font-bold tracking-widest text-xl shadow-inner ring-4 ring-primary/20">
                             {cvvCode || '***'}
                          </div>
                       </div>
                       <div className="mt-12 px-10 text-[8px] text-slate-600 font-bold uppercase tracking-widest leading-relaxed text-center">
                          Issued by Club Cards Partner. If found, please return to any partner bank location worldwide.
                       </div>
                    </div>
                  </div>
               </div>

               <div className="space-y-10 bg-[#151b27] border border-white/5 p-12 rounded-[56px] shadow-2xl">
                  <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/5">
                    <button 
                      onClick={() => { setVerifyMethod('cvv'); setIsCardFlipped(true); }}
                      className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${verifyMethod === 'cvv' ? 'bg-primary text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                    >
                      Security CVV
                    </button>
                    <button 
                      onClick={() => { setVerifyMethod('pin'); setIsCardFlipped(false); }}
                      className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${verifyMethod === 'pin' ? 'bg-primary text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                    >
                      Card PIN
                    </button>
                  </div>

                  {verifyMethod === 'cvv' ? (
                    <div className="animate-in fade-in duration-500">
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Enter 3-Digit CVV</p>
                      <input 
                        type="password"
                        placeholder="***"
                        maxLength={3}
                        value={cvvCode}
                        onChange={(e) => setCvvCode(e.target.value.replace(/\D/g, ''))}
                        className="w-full bg-[#0a0f18] border border-white/10 rounded-2xl py-6 px-8 text-center text-5xl font-mono tracking-[0.5em] focus:ring-4 focus:ring-primary/20 outline-none transition-all"
                      />
                    </div>
                  ) : (
                    <div className="animate-in fade-in duration-500">
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Enter 4-Digit PIN</p>
                      <div className="flex justify-between gap-4">
                        {pinCode.map((val, i) => (
                          <input 
                            key={i}
                            id={`pin-${i}`}
                            type="password"
                            maxLength={1}
                            value={val}
                            onChange={(e) => {
                              const newVal = e.target.value.replace(/\D/g, '');
                              const newPin = [...pinCode];
                              newPin[i] = newVal;
                              setPinCode(newPin);
                              if (newVal && i < 3) document.getElementById(`pin-${i+1}`)?.focus();
                            }}
                            className="w-full bg-[#0a0f18] border border-white/10 rounded-2xl py-6 text-center text-3xl font-bold focus:ring-4 focus:ring-primary/20 outline-none transition-all"
                          />
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <button 
                    onClick={handleVerify}
                    className="w-full py-6 rounded-3xl bg-primary text-white font-black text-xs uppercase tracking-widest shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-4"
                  >
                    Fetch Eligibility
                    <span className="material-symbols-outlined">verified_user</span>
                  </button>
                  <p className="text-[9px] text-center text-slate-600 font-bold uppercase tracking-widest">
                    <span className="material-symbols-outlined text-[12px] align-middle mr-1">security</span>
                    End-to-End Encrypted Verification
                  </p>
               </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="animate-in fade-in duration-700">
            <div className="flex flex-col lg:flex-row justify-between items-end mb-20 gap-10">
              <div className="max-w-2xl">
                <div className="flex items-center gap-3 mb-6 text-emerald-400">
                  <span className="material-symbols-outlined text-xl">verified</span>
                  <span className="text-[10px] font-black uppercase tracking-[0.5em]">Sync Successful</span>
                </div>
                <h1 className="text-6xl font-black tracking-tight mb-6">Your Active Eligibility</h1>
                <p className="text-xl text-slate-400 font-medium leading-relaxed">
                  We've calculated your exact <span className="text-white">Active Benefits</span> based on your current 42,850 points and recent utility spend.
                </p>
              </div>
              
              <div className="bg-[#151b27] border border-white/5 p-10 rounded-[48px] flex items-center gap-10 shadow-2xl min-w-[400px]">
                 <div className="size-20 rounded-3xl bg-primary/10 flex items-center justify-center text-primary shrink-0 border border-primary/20 shadow-inner">
                    <span className="material-symbols-outlined text-4xl">stars</span>
                 </div>
                 <div>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Live Reward Points</p>
                    <p className="text-5xl font-black text-white leading-none">42,850</p>
                    <div className="mt-4 flex items-center gap-2">
                       <span className="text-[10px] font-bold text-emerald-400">+1,200 this week</span>
                       <span className="size-1 rounded-full bg-slate-700"></span>
                       <span className="text-[10px] font-bold text-slate-500 uppercase">Worth ₹10,712</span>
                 </div>
              </div>
            </div>
          </div>

            <div className="grid lg:grid-cols-12 gap-12 mb-20">
               <div className="lg:col-span-8 space-y-12">
                  <div className="grid md:grid-cols-2 gap-8">
                    {activePerks.map((perk, i) => (
                      <div key={i} className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-10 group hover:border-primary/20 transition-all shadow-2xl relative overflow-hidden">
                        <div className={`absolute -bottom-4 -right-4 opacity-0 group-hover:opacity-5 transition-all duration-700 ${perk.color}`}>
                           <span className="material-symbols-outlined text-[160px]">{perk.icon}</span>
                        </div>
                        <div className="flex justify-between items-start mb-8 relative z-10">
                           <div className={`size-16 rounded-2xl bg-white/5 flex items-center justify-center ${perk.color} border border-white/5 shadow-inner group-hover:scale-110 transition-transform`}>
                              <span className="material-symbols-outlined text-3xl">{perk.icon}</span>
                           </div>
                           <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-[9px] font-black uppercase tracking-widest border border-emerald-500/20">{perk.status}</span>
                        </div>
                        <h4 className="text-2xl font-black mb-2 tracking-tight group-hover:text-primary transition-colors relative z-10">{perk.title}</h4>
                        <p className="text-sm text-slate-500 font-medium leading-relaxed relative z-10">{perk.desc}</p>
                      </div>
                    ))}
                  </div>

                  <div className="bg-[#151b27]/60 border border-white/5 rounded-[48px] p-12 shadow-2xl">
                     <h3 className="text-2xl font-black mb-8">Points Value Breakdown</h3>
                     <div className="grid md:grid-cols-3 gap-8">
                        {pointsBreakdown.map((row, i) => (
                           <div key={i} className="p-6 rounded-3xl bg-white/5 border border-white/5 text-center group hover:bg-primary/5 transition-all">
                              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">{row.label}</p>
                              <p className="text-3xl font-black text-white group-hover:text-primary transition-colors">{row.value}</p>
                              <p className="text-[10px] font-bold text-slate-600 mt-2 uppercase">{row.rate}</p>
                           </div>
                        ))}
                     </div>
                  </div>
               </div>

               <div className="lg:col-span-4 space-y-8">
                  <div className="bg-primary/5 border border-primary/10 rounded-[48px] p-10 shadow-2xl backdrop-blur-xl">
                     <h4 className="text-xl font-black mb-8 flex items-center gap-3">
                       <span className="material-symbols-outlined text-primary">redeem</span>
                       Instant Redemptions
                     </h4>
                     <div className="space-y-6">
                        {[
                          { brand: 'Taj Hotels', offer: '15,000 pts / Night', icon: 'hotel' },
                          { brand: 'Apple Store', offer: '₹5,000 Gift Voucher', icon: 'laptop_mac' },
                          { brand: 'Amazon Pay', offer: '₹2,500 Multi-Voucher', icon: 'shopping_cart' }
                        ].map((offer, i) => (
                          <div key={i} className="flex items-center gap-5 p-5 bg-white/5 rounded-3xl border border-white/5 group hover:bg-white/10 cursor-pointer transition-all">
                             <div className="size-12 rounded-xl bg-white/5 flex items-center justify-center text-slate-500 group-hover:text-primary transition-colors">
                                <span className="material-symbols-outlined">{offer.icon}</span>
                             </div>
                             <div>
                                <p className="text-sm font-black text-white">{offer.brand}</p>
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{offer.offer}</p>
                             </div>
                          </div>
                        ))}
                     </div>
                  </div>

                  <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-[48px] p-10 text-center shadow-2xl">
                     <div className="size-16 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 mx-auto mb-6">
                        <span className="material-symbols-outlined text-3xl">upgrade</span>
                     </div>
                     <h4 className="text-lg font-black mb-4 tracking-tight text-white">Infinite Upgrade Eligible</h4>
                     <p className="text-xs text-slate-500 font-medium leading-relaxed mb-8">
                        Your point balance and spend velocity make you eligible for an instant <span className="text-emerald-400 font-bold">Infinite Elite Upgrade</span>.
                     </p>
                     <button className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.3em] flex items-center gap-3 mx-auto hover:gap-5 transition-all">
                        Claim Privilege <span className="material-symbols-outlined text-sm">arrow_forward</span>
                     </button>
                  </div>
               </div>
            </div>

            <div className="p-16 bg-gradient-to-br from-[#1258e2] to-[#002855] rounded-[64px] text-center shadow-[0_64px_160px_-40px_rgba(18,88,226,0.6)] relative overflow-hidden group">
               <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=market')] opacity-5 mix-blend-overlay"></div>
               <div className="relative z-10">
                  <h2 className="text-5xl font-black mb-8 leading-none tracking-tighter">Maximize Your Eligibility</h2>
                  <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto font-medium leading-relaxed">
                     Rotate your utility receipts across your verified card set to increase your <span className="text-white font-bold">Points Yield</span> by up to 42%.
                  </p>
                  <div className="flex flex-wrap justify-center gap-6">
                    <button onClick={() => setStep(1)} className="px-12 py-5 rounded-2xl bg-white text-primary font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 transition-all">
                       Audit My Profile
                    </button>
                  </div>
               </div>
            </div>
          </div>
        )}
      </div>

      <style>{`
        .perspective-[1000px] { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
};

export default MyBenefits;
