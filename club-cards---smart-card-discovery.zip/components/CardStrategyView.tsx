
import React, { useState } from 'react';
import { ALL_CARDS } from '../constants';
import RealisticCard from './RealisticCard';

const CardStrategyView: React.FC = () => {
  const [diningSpend, setDiningSpend] = useState(25000);
  const [travelSpend, setTravelSpend] = useState(40000);
  const [shoppingSpend, setShoppingSpend] = useState(15000);

  const totalSpend = diningSpend + travelSpend + shoppingSpend;
  const missedRewards = (diningSpend * 0.05) + (travelSpend * 0.06) + (shoppingSpend * 0.04);
  const annualLoss = missedRewards * 12;

  // Strategic mapping to real bank products
  const getStrategicMatches = () => {
    const matches = [];
    if (travelSpend > 30000) matches.push(ALL_CARDS.find(c => c.id === 'hdfc-regalia-gold'));
    if (totalSpend > 50000) matches.push(ALL_CARDS.find(c => c.id === 'icici-emeralde'));
    if (shoppingSpend > 10000) matches.push(ALL_CARDS.find(c => c.id === 'axis-magnus'));
    return matches.filter(Boolean).slice(0, 3) as any[];
  };

  const cardMatches = getStrategicMatches();

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1280px] mx-auto">
        
        <div className="mb-24 flex flex-col lg:flex-row justify-between items-end gap-12">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-6 text-primary">
              <span className="material-symbols-outlined">receipt_long</span>
              <span className="text-[10px] font-black uppercase tracking-[0.4em]">Personalizing Receipts</span>
            </div>
            <h1 className="text-7xl lg:text-[100px] font-black tracking-tighter mb-8 leading-none">Receipt Strategy.</h1>
            <p className="text-slate-400 text-2xl font-medium leading-relaxed">
              We analyze your transaction "receipts" to identify the <span className="text-white italic">exact bank card</span> that eliminates financial leakage.
            </p>
          </div>
          <div className="hidden lg:block bg-primary/10 border border-primary/20 px-8 py-4 rounded-full text-[11px] font-black uppercase tracking-widest text-primary animate-pulse">
            Real-Time Bank Yield Monitoring Active
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-16 mb-24">
          <div className="lg:col-span-8 space-y-16">
            <div className="bg-[#151b27] border border-white/5 rounded-[64px] p-12 lg:p-20 shadow-2xl relative overflow-hidden backdrop-blur-3xl">
              <div className="absolute inset-0 bg-primary/5 opacity-40"></div>
              
              <h3 className="text-3xl font-black mb-16 flex items-center gap-6 relative z-10">
                <span className="material-symbols-outlined text-primary text-4xl">tune</span>
                Personalizing Monthly Receipts
              </h3>

              <div className="space-y-16 mb-20 relative z-10">
                <div className="grid md:grid-cols-2 gap-16 items-center">
                   <div>
                      <div className="flex justify-between text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-8">
                        <span>Dining Receipts</span>
                        <span className="text-white font-mono">₹{diningSpend.toLocaleString()}</span>
                      </div>
                      <input 
                        type="range" min="0" max="150000" step="1000" value={diningSpend}
                        onChange={(e) => setDiningSpend(parseInt(e.target.value))}
                        className="w-full h-2.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary"
                      />
                   </div>
                   <div>
                      <div className="flex justify-between text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-8">
                        <span>Travel Receipts</span>
                        <span className="text-white font-mono">₹{travelSpend.toLocaleString()}</span>
                      </div>
                      <input 
                        type="range" min="0" max="300000" step="5000" value={travelSpend}
                        onChange={(e) => setTravelSpend(parseInt(e.target.value))}
                        className="w-full h-2.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary"
                      />
                   </div>
                </div>

                <div className="flex flex-col md:grid-cols-2 gap-12 items-center pt-12 border-t border-white/5">
                   <div className="flex-grow w-full">
                      <div className="flex justify-between text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-8">
                        <span>Shopping & Utility Receipts</span>
                        <span className="text-white font-mono">₹{shoppingSpend.toLocaleString()}</span>
                      </div>
                      <input 
                        type="range" min="0" max="150000" step="1000" value={shoppingSpend}
                        onChange={(e) => setShoppingSpend(parseInt(e.target.value))}
                        className="w-full h-2.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary"
                      />
                   </div>
                   <div className="bg-[#0a0f18]/80 p-10 rounded-[40px] border border-white/5 min-w-[280px] text-center shadow-2xl">
                      <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-3">Portfolio Thru-put</p>
                      <p className="text-5xl font-black text-white">₹{totalSpend.toLocaleString()}</p>
                   </div>
                </div>
              </div>

              <div className="bg-red-500/10 border border-red-500/20 rounded-[48px] p-12 flex flex-col md:flex-row justify-between items-center gap-12 relative z-10">
                 <div>
                    <p className="text-[11px] font-black text-red-400 uppercase tracking-[0.3em] mb-3">Financial Risk Threshold</p>
                    <p className="text-6xl font-black text-red-400">₹{annualLoss.toLocaleString()}<span className="text-2xl"> / YEAR</span></p>
                    <p className="text-sm text-slate-500 font-bold mt-6 leading-relaxed max-w-sm">
                      This represents rewards and benefits "Buying Opportunity" lost to inefficient receipt processing.
                    </p>
                 </div>
                 <button className="px-12 py-6 rounded-[24px] bg-white text-black font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
                    Resolve Risks Now
                 </button>
              </div>
            </div>

            {/* Strategy Matches */}
            <div>
               <h2 className="text-4xl font-black mb-16 flex items-center gap-6">
                 <span className="material-symbols-outlined text-primary text-4xl">verified</span>
                 Bank-Partner Matches
               </h2>
               <div className="grid md:grid-cols-2 gap-12">
                 {cardMatches.map((card, i) => (
                   <div key={i} className="group animate-in fade-in slide-in-from-bottom-8" style={{ animationDelay: `${i * 100}ms` }}>
                      <RealisticCard card={card} className="mb-8 hover:-translate-y-3 transition-transform shadow-[0_40px_80px_-20px_rgba(0,0,0,0.8)]" />
                      <div className="px-4">
                        <div className="flex justify-between items-start mb-4">
                           <div>
                              <h3 className="text-3xl font-black text-white mb-1">{card.name}</h3>
                              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{card.issuer} • {card.category}</p>
                           </div>
                           <span className="text-[9px] font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded-full uppercase">Optimal Match</span>
                        </div>
                        <p className="text-base text-slate-500 font-medium mb-10 leading-relaxed">
                          Strategic Reason: {card.description.split('.')[0]}. Perfect for handling your ₹{totalSpend.toLocaleString()} receipt volume.
                        </p>
                        <button className="text-[11px] font-black text-primary uppercase tracking-[0.3em] flex items-center gap-3 group-hover:gap-5 transition-all">
                          Acquire via {card.issuer} <span className="material-symbols-outlined text-sm">arrow_forward</span>
                        </button>
                      </div>
                   </div>
                 ))}
               </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-12">
            <div className="bg-primary/5 border border-primary/10 rounded-[56px] p-12 shadow-2xl backdrop-blur-xl">
               <h3 className="text-2xl font-black mb-10 flex items-center gap-4 text-red-400">
                 <span className="material-symbols-outlined text-3xl">gpp_maybe</span>
                 Personalized Risks
               </h3>
               <div className="space-y-10">
                  <div className="group">
                     <p className="text-lg font-black mb-3 text-white group-hover:text-red-400 transition-colors">Bank Category Mismatch</p>
                     <p className="text-sm text-slate-500 font-medium leading-relaxed">
                        Your HDFC receipts indicate heavy utility spend. Standard HDFC cards cap these at 1% yield. Consider the <span className="text-white">ICICI Emeralde</span> to bypass this cap.
                     </p>
                  </div>
                  <div className="group">
                     <p className="text-lg font-black mb-3 text-white group-hover:text-red-400 transition-colors">Forex Fee Leakage</p>
                     <p className="text-sm text-slate-500 font-medium leading-relaxed">
                        42% of your travel receipts are international. You are losing ₹{Math.round(annualLoss * 0.3).toLocaleString()} to dynamic currency conversion fees.
                     </p>
                  </div>
                  <div className="group">
                     <p className="text-lg font-black mb-3 text-white group-hover:text-red-400 transition-colors">Reward Concentration</p>
                     <p className="text-sm text-slate-500 font-medium leading-relaxed">
                        Too much volume on Axis Bank cards. Diversify to Federal Bank for higher milestone redemption liquidity.
                     </p>
                  </div>
               </div>
            </div>

            <div className="bg-[#151b27]/60 border border-white/5 rounded-[56px] p-12 shadow-2xl">
               <h3 className="text-2xl font-black mb-10">Card Buying Tips</h3>
               <div className="space-y-6">
                  {[
                    'Leverage HDFC-ICICI "Card-to-Card" transfers for instant approval.',
                    'Check for "Federal Bank" festive season vouchers on new accounts.',
                    'Match Axis card tier to your salary account status for zero fees.',
                    'Inquire about "Buy 1 Get 1" priority for high-limit debit cards.'
                  ].map((tip, i) => (
                    <div key={i} className="flex items-start gap-5 p-6 bg-white/5 rounded-3xl border border-white/5 group hover:border-primary/20 transition-all cursor-default">
                      <span className="material-symbols-outlined text-primary text-2xl group-hover:scale-125 transition-transform">tips_and_updates</span>
                      <span className="text-xs font-bold text-slate-400 leading-relaxed group-hover:text-slate-200 transition-colors">{tip}</span>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>

        {/* Dynamic Benefits Section */}
        <div className="p-20 bg-gradient-to-br from-[#1258e2] to-[#002855] rounded-[80px] text-center shadow-[0_50px_150px_-30px_rgba(18,88,226,0.6)] relative overflow-hidden group">
           <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=bank')] opacity-5 mix-blend-overlay scale-150 group-hover:scale-110 transition-transform duration-[20s] linear infinite"></div>
           <div className="relative z-10">
              <h2 className="text-5xl lg:text-7xl font-black mb-6 tracking-tight">Club Cards Bank Partner Privileges</h2>
              <p className="text-xl text-white/80 mb-16 max-w-3xl mx-auto font-medium leading-relaxed">
                 Unlock <span className="text-white font-bold">Priority Processing</span> across HDFC, ICICI, and Axis bank networks. Get exclusive joining fee waivers and personalized RM support for all premium products.
              </p>
              <div className="flex flex-wrap justify-center gap-6">
                 <button className="px-12 py-6 rounded-[24px] bg-white text-primary font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
                    View Pre-Approved Bank List
                 </button>
                 <button className="px-12 py-6 rounded-[24px] bg-white/10 border border-white/20 text-white font-black text-xs uppercase tracking-widest hover:bg-white/20 transition-all">
                    Contact Bank RM
                 </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CardStrategyView;
