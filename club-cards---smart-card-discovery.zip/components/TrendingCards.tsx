
import React from 'react';
// Fix: Import ALL_CARDS instead of non-existent FEATURED_CARDS
import { ALL_CARDS } from '../constants';
import RealisticCard from './RealisticCard';

interface TrendingCardsProps {
  onViewAll: () => void;
}

const TrendingCards: React.FC<TrendingCardsProps> = ({ onViewAll }) => {
  // Fix: Select a few cards to display as "trending"
  const trendingList = ALL_CARDS.slice(0, 3);

  return (
    <section className="py-24 relative overflow-hidden bg-white dark:bg-[#0a0f18]">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="relative max-w-[1280px] mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-xl">
            <div className="flex items-center gap-3 mb-4 text-primary">
              <span className="h-2 w-8 bg-primary rounded-full"></span>
              <span className="text-[10px] font-black uppercase tracking-[0.4em]">Curated Selection</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight mb-4">Trending Premium Cards</h2>
            <p className="text-slate-500 font-medium">A masterclass in financial engineering and aesthetic prestige.</p>
          </div>
          <button 
            onClick={onViewAll}
            className="group flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-white/5 border border-white/5 text-[11px] font-black uppercase tracking-widest text-slate-400 hover:text-white hover:bg-white/10 transition-all"
          >
            View Full Catalog
            <span className="material-symbols-outlined text-lg transition-transform group-hover:translate-x-1">arrow_forward</span>
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {trendingList.map((card) => (
            <div key={card.id} className="group flex flex-col gap-8">
              <div className="hover:-translate-y-4 transition-all duration-700">
                <RealisticCard card={card} />
              </div>
              <div className="px-2">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight mb-1">{card.name}</h3>
                    <p className="text-xs text-slate-500 font-black uppercase tracking-widest">{card.finish} Finish</p>
                  </div>
                  <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest bg-primary/10 text-primary`}>
                    {card.badge}
                  </span>
                </div>
                <p className="text-sm text-slate-500 font-medium leading-relaxed mb-8">{card.description}</p>
                <div className="grid grid-cols-2 gap-8 pt-6 border-t border-gray-100 dark:border-white/5">
                  {card.stats.map((stat, i) => (
                    <div key={i}>
                      <p className="text-[10px] uppercase text-slate-400 font-black tracking-widest mb-1">{stat.label}</p>
                      <p className="text-lg font-black text-slate-900 dark:text-white tracking-tight">{stat.value}</p>
                    </div>
                  ))}
                </div>
                <button className="w-full mt-10 py-4 rounded-2xl bg-primary text-white font-black text-xs uppercase tracking-widest shadow-2xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all">
                  Secure Application
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrendingCards;
