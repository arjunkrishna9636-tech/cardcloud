
import React from 'react';
import { CategoryMetadata, CreditCard } from '../types';
import RealisticCard from './RealisticCard';
import { ALL_CARDS } from '../constants';

interface CategoryDetailProps {
  category: CategoryMetadata;
  onBack: () => void;
}

const CategoryDetail: React.FC<CategoryDetailProps> = ({ category, onBack }) => {
  const filteredCards = ALL_CARDS.filter(c => c.category === category.name);

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="max-w-[1440px] mx-auto">
        {/* Navigation & Header */}
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-white mb-12 font-black text-[10px] uppercase tracking-[0.3em] transition-all group"
        >
          <span className="material-symbols-outlined text-sm group-hover:-translate-x-1 transition-transform">arrow_back</span>
          Back to Categories
        </button>

        <div className="grid lg:grid-cols-2 gap-20 items-center mb-24">
          <div>
            <div className={`inline-flex items-center gap-3 px-4 py-2 rounded-full bg-gradient-to-r ${category.color} opacity-90 text-white text-[10px] font-black uppercase tracking-[0.4em] mb-8 shadow-xl`}>
              <span className="material-symbols-outlined text-sm">{category.icon}</span>
              Sector: {category.name}
            </div>
            <h1 className="text-7xl lg:text-[110px] font-black tracking-tighter mb-8 leading-[0.9]">
              {category.name.split(' ').map((word, i) => (
                <span key={i} className={i === 0 ? 'text-white' : 'text-primary italic block'}>{word} </span>
              ))}
            </h1>
            <p className="text-2xl text-slate-400 font-medium leading-relaxed max-w-xl">
              {category.desc} Explore the <span className="text-white italic">regulatory framework</span> and instruments available for this class.
            </p>
          </div>

          <div className="relative">
            <div className={`absolute inset-0 bg-gradient-to-br ${category.color} blur-[120px] opacity-20 rounded-full`}></div>
            <div className="relative glass-panel rounded-[64px] p-12 shadow-2xl border border-white/10">
               <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-8">Category Benefits Index</h3>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {category.benefits.map((benefit, i) => (
                    <div key={i} className="flex items-center gap-4 p-5 rounded-3xl bg-white/5 border border-white/5 group hover:border-primary/30 transition-all">
                       <span className="material-symbols-outlined text-primary">verified</span>
                       <span className="text-sm font-bold text-slate-200">{benefit}</span>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>

        {/* Declarations Section */}
        <div className="grid md:grid-cols-2 gap-12 mb-24">
           <div className="bg-[#151b27]/60 border border-white/5 rounded-[56px] p-12 lg:p-16 shadow-2xl relative overflow-hidden group">
              <div className="flex items-center gap-4 mb-8">
                <span className="material-symbols-outlined text-primary text-4xl">public</span>
                <h3 className="text-3xl font-black">Global Declaration</h3>
              </div>
              <p className="text-lg text-slate-400 font-medium leading-relaxed mb-10">
                {category.globalDeclaration}
              </p>
              <div className="pt-8 border-t border-white/5">
                 <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Standard Compliance</p>
                 <div className="flex gap-4">
                    <span className="text-[10px] font-bold text-white/50">Basel III Accord</span>
                    <span className="text-[10px] font-bold text-white/50">PCI-DSS v4.0</span>
                    <span className="text-[10px] font-bold text-white/50">AML Global Registry</span>
                 </div>
              </div>
           </div>

           <div className="bg-[#151b27]/60 border border-white/5 rounded-[56px] p-12 lg:p-16 shadow-2xl relative overflow-hidden group">
              <div className="flex items-center gap-4 mb-8">
                <span className="material-symbols-outlined text-primary text-4xl">assured_workload</span>
                <h3 className="text-3xl font-black">India Declaration</h3>
              </div>
              <p className="text-lg text-slate-400 font-medium leading-relaxed mb-10">
                {category.indiaDeclaration}
              </p>
              <div className="pt-8 border-t border-white/5">
                 <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Local Compliance</p>
                 <div className="flex gap-4">
                    <span className="text-[10px] font-bold text-white/50">RBI Master Direction</span>
                    <span className="text-[10px] font-bold text-white/50">NPCI Network Rule</span>
                    <span className="text-[10px] font-bold text-white/50">IT Act 2000</span>
                 </div>
              </div>
           </div>
        </div>

        {/* Card Gallery for this Category */}
        <div className="mb-24">
          <div className="flex justify-between items-end mb-16">
             <div>
                <h2 className="text-5xl font-black tracking-tight mb-2">Available Instruments</h2>
                <p className="text-slate-500 font-medium">Curated {category.name} across our partner banking network.</p>
             </div>
             <div className="flex gap-4">
                <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                   {filteredCards.length} Cards Found
                </div>
             </div>
          </div>

          {filteredCards.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12">
              {filteredCards.map((card, i) => (
                <div key={card.id} className="animate-in fade-in slide-in-from-bottom-8 duration-700" style={{ animationDelay: `${i * 100}ms` }}>
                  <RealisticCard card={card} className="mb-8 hover:-translate-y-4 transition-transform shadow-2xl" />
                  <div className="px-2">
                    <h4 className="text-2xl font-black mb-1">{card.name}</h4>
                    <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-6">{card.issuer} • {card.type}</p>
                    <button className="w-full py-4 rounded-2xl bg-primary text-white font-black text-[10px] uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all">
                      Apply Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-24 rounded-[64px] border border-white/5 border-dashed text-center">
               <span className="material-symbols-outlined text-7xl text-slate-800 mb-6">search_off</span>
               <h3 className="text-2xl font-black text-slate-600">No specific cards in our live catalog yet.</h3>
               <p className="text-slate-700 mt-2 font-medium">Check back soon for new partner integrations for {category.name}.</p>
            </div>
          )}
        </div>

        {/* Strategy Footer */}
        <div className={`p-20 bg-gradient-to-br ${category.color} rounded-[80px] text-center shadow-2xl relative overflow-hidden group`}>
           <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=strategy')] opacity-10 mix-blend-overlay"></div>
           <div className="relative z-10">
              <h2 className="text-5xl font-black mb-8 leading-none tracking-tighter">Optimize Your {category.name} Strategy</h2>
              <p className="text-xl text-white/80 max-w-3xl mx-auto font-medium leading-relaxed mb-12">
                 Leverage our AI analyzer to see if your spending receipts match the high-yield criteria for {category.name}. Most users save up to 15% on monthly utility expenses by switching to the correct instrument.
              </p>
              <button className="px-16 py-6 rounded-[24px] bg-white text-black font-black text-[11px] uppercase tracking-[0.4em] shadow-2xl hover:scale-105 transition-all">
                 Analyze My Spending
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryDetail;
