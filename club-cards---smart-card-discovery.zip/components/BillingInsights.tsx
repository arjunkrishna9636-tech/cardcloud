
import React, { useState } from 'react';

type Period = 'This Month' | 'Last Month' | 'YTD';

interface PeriodData {
  totalSpend: string;
  spendTrend: string;
  spendPercent: number;
  cashFlow: string;
  pending: string;
  chartPoints: string;
  tooltipValue: string;
}

const BillingInsights: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Period>('This Month');

  const dataMap: Record<Period, PeriodData> = {
    'This Month': {
      totalSpend: '₹1,42,250',
      spendTrend: '5%',
      spendPercent: 65,
      cashFlow: '+₹32,240.00',
      pending: '₹8,450.20',
      chartPoints: "M 0 160 Q 100 140, 200 120 T 400 80 T 600 100 T 800 60",
      tooltipValue: '₹2,104.50'
    },
    'Last Month': {
      totalSpend: '₹1,28,400',
      spendTrend: '-2%',
      spendPercent: 58,
      cashFlow: '+₹29,150.00',
      pending: '₹1,120.00',
      chartPoints: "M 0 180 Q 150 160, 300 140 T 500 110 T 700 130 T 800 90",
      tooltipValue: '₹1,850.00'
    },
    'YTD': {
      totalSpend: '₹15,42,000',
      spendTrend: '12%',
      spendPercent: 82,
      cashFlow: '+₹4,12,800.00',
      pending: '₹22,450.00',
      chartPoints: "M 0 190 Q 200 150, 400 100 T 600 40 T 800 20",
      tooltipValue: '₹48,200.00'
    }
  };

  const currentData = dataMap[activeTab];

  return (
    <div className="flex h-[calc(100vh-80px)] bg-[#0a0f18] text-white overflow-hidden animate-in fade-in duration-500">
      {/* Sidebar Navigation matching the design */}
      <aside className="w-72 border-r border-white/5 bg-[#0a0f18] flex flex-col p-8 shrink-0">
        <div className="flex items-center gap-3 mb-12">
          <div className="size-10 rounded-full bg-slate-700 overflow-hidden border border-white/10">
             <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Morgan" alt="Avatar" />
          </div>
          <div>
            <p className="text-sm font-black">FinTech Corp</p>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Premium Member</p>
          </div>
        </div>

        <nav className="space-y-2 mb-auto">
          <button className="w-full flex items-center gap-4 px-6 py-3.5 rounded-xl text-slate-500 hover:bg-white/5 hover:text-white transition-all font-bold text-sm">
            <span className="material-symbols-outlined text-xl">grid_view</span>
            Dashboard
          </button>
          <button className="w-full flex items-center gap-4 px-6 py-3.5 rounded-xl text-slate-500 hover:bg-white/5 hover:text-white transition-all font-bold text-sm">
            <span className="material-symbols-outlined text-xl">credit_card</span>
            Cards
          </button>
          <button className="w-full flex items-center gap-4 px-6 py-3.5 rounded-xl bg-white/5 text-primary border border-white/5 shadow-lg font-bold text-sm">
            <span className="material-symbols-outlined text-xl">insights</span>
            Insights
          </button>
          <button className="w-full flex items-center gap-4 px-6 py-3.5 rounded-xl text-slate-500 hover:bg-white/5 hover:text-white transition-all font-bold text-sm">
            <span className="material-symbols-outlined text-xl">payments</span>
            Payments
          </button>
          <button className="w-full flex items-center gap-4 px-6 py-3.5 rounded-xl text-slate-500 hover:bg-white/5 hover:text-white transition-all font-bold text-sm">
            <span className="material-symbols-outlined text-xl">settings</span>
            Settings
          </button>
        </nav>

        <div className="mt-8 bg-[#151b27] border border-white/5 rounded-3xl p-6">
           <div className="flex items-center gap-3 mb-4">
              <div className="size-8 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                 <span className="material-symbols-outlined text-lg">support_agent</span>
              </div>
              <p className="text-xs font-black uppercase tracking-widest">Concierge</p>
           </div>
           <p className="text-xs text-slate-500 font-medium leading-relaxed mb-6">Need help with a transaction?</p>
           <button className="w-full py-3 rounded-xl bg-primary hover:bg-blue-600 text-white font-black text-[10px] uppercase tracking-widest shadow-lg shadow-primary/20 transition-all">
             Contact Support
           </button>
        </div>
      </aside>

      {/* Main Billing & Insights Content */}
      <main className="flex-grow overflow-y-auto p-12 scrollbar-hide">
        <div className="max-w-[1200px] mx-auto">
          
          <div className="flex justify-between items-start mb-10">
            <div>
              <h1 className="text-4xl font-black tracking-tight mb-2">Billing & Insights</h1>
              <p className="text-slate-500 text-sm font-medium">Manage your spending, payments, and rewards across all accounts.</p>
            </div>
            <div className="flex p-1.5 bg-white/5 rounded-xl border border-white/5 shadow-inner">
               {(['This Month', 'Last Month', 'YTD'] as Period[]).map(t => (
                 <button 
                  key={t}
                  onClick={() => setActiveTab(t)}
                  className={`px-6 py-2 rounded-lg text-xs font-black transition-all ${activeTab === t ? 'bg-[#1c2331] text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
                 >
                   {t}
                 </button>
               ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 mb-10">
            {/* Left Section: Stats & Spending Trends */}
            <div className="lg:col-span-8 space-y-8">
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-10 relative overflow-hidden group">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Total Monthly Spend</p>
                      <h2 className="text-4xl font-black transition-all duration-500">{currentData.totalSpend}<span className="text-lg text-slate-600">.00</span></h2>
                    </div>
                    <div className={`flex items-center gap-1 ${currentData.spendTrend.startsWith('+') ? 'bg-emerald-400/10 text-emerald-400' : 'bg-red-400/10 text-red-400'} px-2 py-0.5 rounded text-[10px] font-black uppercase transition-all`}>
                       <span className="material-symbols-outlined text-xs">{currentData.spendTrend.startsWith('+') ? 'trending_up' : 'trending_down'}</span>
                       {currentData.spendTrend}
                    </div>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full mb-3 overflow-hidden">
                    <div className="h-full bg-primary transition-all duration-700" style={{ width: `${currentData.spendPercent}%` }}></div>
                  </div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{currentData.spendPercent}% of monthly budget</p>
                  <div className="absolute top-10 right-10 opacity-5 group-hover:opacity-10 transition-opacity">
                     <span className="material-symbols-outlined text-6xl">account_balance_wallet</span>
                  </div>
                </div>

                <div className="grid grid-rows-2 gap-6">
                  <div className="bg-[#151b27]/60 border border-white/5 rounded-[32px] p-8 flex justify-between items-center group cursor-default">
                    <div>
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Cash Flow</p>
                      <h3 className="text-2xl font-black text-white transition-all duration-500">{currentData.cashFlow}</h3>
                    </div>
                    <div className="size-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                       <span className="material-symbols-outlined">south_west</span>
                    </div>
                  </div>
                  <div className="bg-[#151b27]/60 border border-white/5 rounded-[32px] p-8 flex justify-between items-center group cursor-default">
                    <div>
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Pending</p>
                      <h3 className="text-2xl font-black text-white transition-all duration-500">{currentData.pending}</h3>
                    </div>
                    <div className="size-12 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-400 group-hover:rotate-12 transition-transform">
                       <span className="material-symbols-outlined">hourglass_empty</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Spending Trends Chart */}
              <div className="bg-[#151b27]/60 border border-white/5 rounded-[48px] p-10 shadow-2xl relative overflow-hidden">
                <div className="flex justify-between items-start mb-12">
                   <div>
                      <h3 className="text-xl font-black mb-1">Spending Trends</h3>
                      <p className="text-xs text-slate-500 font-medium">Daily spending over current period</p>
                   </div>
                   <button className="text-slate-600 hover:text-white">
                      <span className="material-symbols-outlined">more_horiz</span>
                   </button>
                </div>
                
                <div className="h-48 relative mb-8">
                   <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 800 200">
                      <path 
                        d={currentData.chartPoints} 
                        fill="none" 
                        stroke="#1258e2" 
                        strokeWidth="4" 
                        strokeLinecap="round" 
                        className="transition-all duration-1000"
                      />
                      <path 
                        d={`${currentData.chartPoints} L 800 200 L 0 200 Z`} 
                        fill="url(#spendGrad)" 
                        opacity="0.1" 
                        className="transition-all duration-1000"
                      />
                      <circle cx="500" cy="100" r="5" fill="white" stroke="#1258e2" strokeWidth="3" />
                      <defs>
                        <linearGradient id="spendGrad" x1="0" y1="0" x2="0" y2="1">
                           <stop offset="0%" stopColor="#1258e2" />
                           <stop offset="100%" stopColor="transparent" />
                        </linearGradient>
                      </defs>
                   </svg>
                   <div className="absolute top-[10px] left-[480px] bg-[#1c2331] px-3 py-1.5 rounded-xl border border-white/10 shadow-2xl flex items-center gap-2">
                      <span className="text-xs font-black">{currentData.tooltipValue}</span>
                   </div>
                </div>

                <div className="flex justify-between px-2 text-[10px] font-black text-slate-600 uppercase tracking-widest">
                   <span>Week 1</span>
                   <span>Week 2</span>
                   <span>Week 3</span>
                   <span>Week 4</span>
                </div>
              </div>
            </div>

            {/* Right Section: Payment Alerts & Rewards */}
            <div className="lg:col-span-4 space-y-8">
              <div className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-8">
                <div className="flex justify-between items-center mb-8">
                   <h3 className="text-lg font-black tracking-tight">Payment Alerts</h3>
                   <span className="px-2 py-0.5 rounded bg-orange-500/10 text-orange-500 text-[10px] font-black uppercase tracking-widest">2 Actions</span>
                </div>
                
                <div className="space-y-6">
                   <div className="flex gap-4 group">
                      <div className="size-2 rounded-full bg-red-500 mt-1 shrink-0 animate-pulse"></div>
                      <div className="flex-grow">
                         <div className="flex justify-between items-start mb-1">
                            <p className="text-sm font-black">Gold Card Payment</p>
                            <p className="text-[10px] font-black text-red-400 uppercase tracking-widest">Due Today</p>
                         </div>
                         <p className="text-[10px] text-slate-500 font-bold mb-3">Minimum due: ₹12,000.00</p>
                         <div className="flex items-center gap-4">
                            <button className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline">Pay Now</button>
                            <p className="text-[9px] text-slate-600 font-bold flex items-center gap-1">
                               <span className="material-symbols-outlined text-[12px] text-orange-400">warning</span>
                               Avoid ₹2,500 late fee
                            </p>
                         </div>
                      </div>
                   </div>

                   <div className="flex gap-4 opacity-70 hover:opacity-100 transition-opacity">
                      <div className="size-2 rounded-full bg-yellow-500 mt-1 shrink-0"></div>
                      <div className="flex-grow">
                         <div className="flex justify-between items-start mb-1">
                            <p className="text-sm font-black">Platinum Auto-Pay</p>
                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sep 24</p>
                         </div>
                         <p className="text-[10px] text-slate-500 font-bold">Scheduled: ₹45,520.00</p>
                      </div>
                      <span className="material-symbols-outlined text-slate-700 text-sm">chevron_right</span>
                   </div>
                </div>

                <button className="w-full mt-10 py-3 rounded-xl border border-white/5 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-white hover:bg-white/5 transition-all">
                  View All Payments
                </button>
              </div>

              <div className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-8">
                <div className="flex justify-between items-center mb-10">
                   <h3 className="text-lg font-black tracking-tight">Reward Points</h3>
                   <button className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline">Redeem</button>
                </div>
                
                <div className="space-y-8">
                   <div>
                      <div className="flex justify-between items-center mb-3">
                         <div className="flex items-center gap-3">
                            <span className="material-symbols-outlined text-blue-400 text-xl">flight</span>
                            <p className="text-xs font-black text-slate-300">Sapphire Reserve</p>
                         </div>
                         <p className="text-sm font-black">54,000 <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">pts</span></p>
                      </div>
                      <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                         <div className="h-full bg-blue-400" style={{ width: '60%' }}></div>
                      </div>
                      <p className="text-[9px] text-right text-slate-600 mt-2 font-black uppercase tracking-widest">6k to next tier</p>
                   </div>

                   <div>
                      <div className="flex justify-between items-center mb-3">
                         <div className="flex items-center gap-3">
                            <span className="material-symbols-outlined text-purple-400 text-xl">shopping_bag</span>
                            <p className="text-xs font-black text-slate-300">Amex Platinum</p>
                         </div>
                         <p className="text-sm font-black">120,450 <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">pts</span></p>
                      </div>
                      <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                         <div className="h-full bg-purple-400" style={{ width: '85%' }}></div>
                      </div>
                      <p className="text-[9px] text-right text-slate-600 mt-2 font-black uppercase tracking-widest">Eligible for Business Class upgrade</p>
                   </div>
                </div>
              </div>
            </div>
          </div>

          {/* Individual Card Snapshot */}
          <div className="mb-12">
            <h3 className="text-2xl font-black mb-8 tracking-tight">Your Cards</h3>
            <div className="grid md:grid-cols-3 gap-8">
               <div className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-10 flex flex-col justify-between group cursor-default">
                  <div className="flex justify-between items-start mb-10">
                     <span className="material-symbols-outlined text-white/20">diamond</span>
                     <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">**** 4582</span>
                  </div>
                  <div>
                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Current Balance</p>
                     <p className="text-3xl font-black mb-6">₹34,500.20</p>
                     <div className="flex justify-between items-center pt-6 border-t border-white/5">
                        <div className="flex flex-col">
                           <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Limit</span>
                           <span className="text-xs font-black">₹5,00,000</span>
                        </div>
                        <div className="flex items-center gap-2">
                           <div className="size-2 rounded-full bg-emerald-400"></div>
                           <span className="text-[10px] font-black uppercase tracking-widest">Active</span>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-10 flex flex-col justify-between group cursor-default">
                  <div className="flex justify-between items-start mb-10">
                     <span className="material-symbols-outlined text-white/20">flight</span>
                     <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">**** 8821</span>
                  </div>
                  <div>
                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Current Balance</p>
                     <p className="text-3xl font-black mb-6">₹81,200.50</p>
                     <div className="flex justify-between items-center pt-6 border-t border-white/5">
                        <div className="flex flex-col">
                           <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Limit</span>
                           <span className="text-xs font-black">₹2,50,000</span>
                        </div>
                        <div className="flex flex-col text-right">
                           <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Utilization</span>
                           <span className="text-xs font-black text-orange-400">32%</span>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="bg-[#0a0f18]/40 border border-white/5 border-dashed rounded-[40px] p-10 flex flex-col items-center justify-center gap-6 group cursor-pointer hover:bg-white/5 transition-all">
                  <div className="size-16 rounded-full bg-white/5 flex items-center justify-center text-slate-600 group-hover:text-primary group-hover:bg-primary/10 transition-all">
                     <span className="material-symbols-outlined text-3xl">add</span>
                  </div>
                  <div className="text-center">
                     <p className="text-lg font-black mb-1">Connect New Card</p>
                     <p className="text-xs text-slate-600 font-medium">Add a credit line or bank account</p>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default BillingInsights;
