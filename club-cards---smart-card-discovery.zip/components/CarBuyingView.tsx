
import React, { useState } from 'react';

const CarBuyingView: React.FC = () => {
  const [monthlyIncome, setMonthlyIncome] = useState(85000);
  const [savings, setSavings] = useState(500000);

  // Simple 20/4/10 Rule Calculation
  const maxEMI = monthlyIncome * 0.1;
  const recommendedDownpayment = savings * 0.6;
  const suggestedCarBudget = (maxEMI * 48) + recommendedDownpayment;

  const carMatches = [
    { name: 'Luxury Sedan', range: '₹45L - ₹65L', icon: 'directions_car', match: suggestedCarBudget > 5000000 ? 'High' : 'Stretch' },
    { name: 'Premium SUV', range: '₹25L - ₹40L', icon: 'airport_shuttle', match: suggestedCarBudget > 3000000 ? 'Perfect' : 'High' },
    { name: 'Executive EV', range: '₹15L - ₹25L', icon: 'electric_car', match: 'Perfect' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1200px] mx-auto">
        
        {/* Header Section */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-4 text-primary">
            <span className="material-symbols-outlined">auto_awesome</span>
            <span className="text-[10px] font-black uppercase tracking-[0.4em]">Personalized Auto Guide</span>
          </div>
          <h1 className="text-5xl lg:text-7xl font-black tracking-tight mb-4 leading-none">Your Car Buying Strategy</h1>
          <p className="text-slate-400 text-lg max-w-2xl font-medium">
            Personalizing your receipts and financial strength to help you buy the right car with zero <span className="text-white">Financial Risk</span>.
          </p>
        </div>

        {/* Strategy Analyzer */}
        <div className="grid lg:grid-cols-12 gap-10 mb-20">
          <div className="lg:col-span-8 space-y-8">
            <div className="bg-[#151b27] border border-white/5 rounded-[48px] p-10 shadow-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
              <div className="grid md:grid-cols-2 gap-12 mb-10 relative z-10">
                <div>
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Confirm Monthly Income</p>
                   <input 
                    type="range" 
                    min="30000" 
                    max="500000" 
                    step="5000"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary mb-6"
                   />
                   <div className="bg-[#0a0f18]/60 p-6 rounded-2xl border border-white/5">
                      <p className="text-3xl font-black">₹{monthlyIncome.toLocaleString()}</p>
                   </div>
                </div>
                <div>
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Downpayment Fund</p>
                   <div className="flex justify-between items-center bg-[#0a0f18]/60 p-6 rounded-2xl border border-white/5">
                      <input 
                        type="number" 
                        value={savings}
                        onChange={(e) => setSavings(parseInt(e.target.value))}
                        className="bg-transparent text-3xl font-black outline-none w-full"
                      />
                   </div>
                </div>
              </div>

              <div className="border-t border-white/5 pt-10 grid md:grid-cols-3 gap-8 relative z-10">
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Max Sustainable EMI</p>
                  <p className="text-3xl font-black text-emerald-400">₹{maxEMI.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Recommended Budget</p>
                  <p className="text-3xl font-black text-white">₹{suggestedCarBudget.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Risk Profile</p>
                  <p className="text-3xl font-black text-blue-400">Conservative</p>
                </div>
              </div>
            </div>

            {/* Matches Section */}
            <div>
               <h2 className="text-2xl font-black mb-8 flex items-center gap-3">
                 <span className="material-symbols-outlined text-primary">analytics</span>
                 Personalized Matches
               </h2>
               <div className="grid md:grid-cols-3 gap-6">
                 {carMatches.map((car, i) => (
                   <div key={i} className="bg-[#151b27]/60 border border-white/5 rounded-[32px] p-8 group hover:border-primary/20 transition-all shadow-xl">
                      <div className="size-16 rounded-2xl bg-white/5 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
                         <span className="material-symbols-outlined text-3xl">{car.icon}</span>
                      </div>
                      <h3 className="text-xl font-black mb-1">{car.name}</h3>
                      <p className="text-xs text-slate-500 font-bold mb-6">{car.range}</p>
                      <div className="flex justify-between items-center">
                         <span className={`text-[10px] font-black uppercase tracking-widest ${car.match === 'Perfect' ? 'text-emerald-400' : 'text-primary'}`}>{car.match} Fit</span>
                         <button className="material-symbols-outlined text-slate-700 hover:text-white">arrow_forward</button>
                      </div>
                   </div>
                 ))}
               </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-8">
            <div className="bg-primary/10 border border-primary/20 rounded-[40px] p-10">
               <h3 className="text-xl font-black mb-6 flex items-center gap-3">
                 <span className="material-symbols-outlined">warning</span>
                 Personalized Risks
               </h3>
               <ul className="space-y-6">
                 <li className="flex gap-4">
                   <span className="material-symbols-outlined text-orange-400 shrink-0">report_problem</span>
                   <div>
                     <p className="text-sm font-black mb-1">Depreciation Alert</p>
                     <p className="text-xs text-slate-400 leading-relaxed font-medium">New cars lose ~20% value in the first year. We recommend buying 2-year-old certified pre-owned.</p>
                   </div>
                 </li>
                 <li className="flex gap-4">
                   <span className="material-symbols-outlined text-orange-400 shrink-0">report_problem</span>
                   <div>
                     <p className="text-sm font-black mb-1">Insurance Complexity</p>
                     <p className="text-xs text-slate-400 leading-relaxed font-medium">Add-on covers can increase premiums by 40%. Our partner cards offer complimentary GAP insurance.</p>
                   </div>
                 </li>
               </ul>
            </div>

            <div className="bg-[#151b27]/60 border border-white/5 rounded-[40px] p-10">
               <h3 className="text-xl font-black mb-6">Buyer's Tip Sheet</h3>
               <div className="space-y-4">
                  {[
                    'Negotiate on the Ex-Showroom price only.',
                    'Always test drive during busy traffic hours.',
                    'Inquire about December manufacturing discounts.',
                    'Use Club Cards Credit Line for better ROI vs Dealer Loans.'
                  ].map((tip, i) => (
                    <div key={i} className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/5">
                      <span className="material-symbols-outlined text-primary text-sm">tips_and_updates</span>
                      <span className="text-xs font-bold text-slate-300">{tip}</span>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="p-12 bg-gradient-to-br from-primary to-blue-800 rounded-[56px] text-center shadow-2xl relative overflow-hidden group">
           <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=car')] opacity-10 mix-blend-overlay"></div>
           <div className="relative z-10">
              <h2 className="text-4xl font-black mb-4">Club Cards Client Benefits</h2>
              <p className="text-lg text-white/80 mb-10 max-w-2xl mx-auto font-medium leading-relaxed">
                 As a Club Cards member, you get <span className="text-white font-bold">Priority Dealership Access</span>, 1% lower ROI on Auto Loans, and complimentary Roadside Assistance for 3 years.
              </p>
              <button className="px-12 py-5 rounded-2xl bg-white text-primary font-black text-xs uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
                 Generate Pre-Approval Letter
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CarBuyingView;
