
import React, { useState, useEffect } from 'react';
import { AppView } from '../types';

interface CardFinderProps {
  onComplete: (data: any) => void;
}

const CardFinder: React.FC<CardFinderProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    income: 35000,
    employment: 'Salaried',
    tenure: '2-5 Years',
    focus: 'Travel Rewards',
    lifestyle: 'Urban Professional',
    stabilityGoal: 'Long-term Growth'
  });
  const [analyzing, setAnalyzing] = useState(false);

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const startAnalysis = () => {
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
      onComplete(formData);
    }, 4000);
  };

  const getIncomeBracket = (income: number) => {
    if (income < 40000) return { label: 'Essential', color: 'text-slate-400', desc: 'Entry-level premier cards' };
    if (income < 100000) return { label: 'Executive', color: 'text-blue-400', desc: 'Mid-tier lifestyle rewards' };
    return { label: 'Elite', color: 'text-primary', desc: 'Luxury & unlimited benefits' };
  };

  const bracket = getIncomeBracket(formData.income);

  if (analyzing) {
    return (
      <div className="min-h-screen bg-[#0a0f18] flex items-center justify-center p-6 animate-in fade-in duration-500">
        <div className="text-center max-w-lg">
          <div className="relative size-40 mx-auto mb-12">
            <div className="absolute inset-0 border-4 border-primary/10 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin" style={{ animationDuration: '1.5s' }}></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="material-symbols-outlined text-5xl text-primary animate-pulse">analytics</span>
            </div>
          </div>
          <h2 className="text-4xl font-black mb-6 tracking-tight">Financial Strength Analysis</h2>
          <div className="space-y-4 mb-12">
            <p className="text-slate-400 font-medium leading-relaxed">
              Evaluating your <span className="text-white font-bold">₹{formData.income.toLocaleString()}</span> income stability...
            </p>
            <div className="flex justify-center gap-8">
               <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <span className="material-symbols-outlined text-emerald-400 text-sm">check_circle</span>
                  Lender Compliance
               </div>
               <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                  <span className="material-symbols-outlined text-emerald-400 text-sm">check_circle</span>
                  Tenure Verified
               </div>
            </div>
          </div>
          <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden max-w-xs mx-auto">
             <div className="h-full bg-primary animate-[loading_4s_ease-in-out_forwards]"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-20 pb-24 px-6 animate-in fade-in duration-700">
      <div className="max-w-4xl mx-auto">
        {/* Progress Header */}
        <div className="mb-20 flex justify-between items-center px-2">
          {[1, 2, 3, 4].map(s => (
            <div key={s} className="flex items-center">
              <div className={`size-10 rounded-2xl flex items-center justify-center font-black transition-all duration-500 ${step >= s ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-white/5 text-slate-600'}`}>
                {s}
              </div>
              {s < 4 && <div className={`w-12 md:w-24 h-0.5 mx-4 rounded-full transition-all duration-500 ${step > s ? 'bg-primary' : 'bg-white/5'}`}></div>}
            </div>
          ))}
        </div>

        <div className="bg-[#151b27]/60 border border-white/5 rounded-[48px] p-8 md:p-16 shadow-2xl relative overflow-hidden backdrop-blur-xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
          
          {step === 1 && (
            <div className="animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center gap-3 mb-4 text-primary">
                 <span className="material-symbols-outlined">payments</span>
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Financial Stability</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-6 tracking-tight">Analyze Your Monthly Income</h2>
              <p className="text-slate-500 mb-12 font-medium leading-relaxed max-w-xl">
                Lenders assess your income to determine your <span className="text-white">Credit Strength</span>. Your monthly take-home determines your limit and eligibility for premium perks.
              </p>
              
              <div className="space-y-10">
                 <div className="relative py-4">
                    <input 
                      type="range" 
                      min="15000" 
                      max="300000" 
                      step="5000"
                      value={formData.income}
                      onChange={(e) => setFormData({...formData, income: parseInt(e.target.value)})}
                      className="w-full h-2 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary"
                    />
                    <div className="flex justify-between mt-4 text-[10px] font-black text-slate-600 uppercase tracking-widest">
                       <span>₹15k</span>
                       <span>₹300k+</span>
                    </div>
                 </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    <div className="bg-[#0a0f18]/60 border border-white/5 p-8 rounded-[32px] text-center border-l-4 border-l-primary">
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Selected Income</p>
                      <p className="text-5xl font-black text-white mb-2">₹{formData.income.toLocaleString()}</p>
                      <p className={`text-xs font-bold ${bracket.color} uppercase tracking-widest`}>{bracket.label} Bracket</p>
                    </div>
                    <div className="p-4">
                       <h4 className="text-sm font-black mb-3 flex items-center gap-2">
                          <span className="material-symbols-outlined text-primary text-sm">info</span>
                          Why this matters:
                       </h4>
                       <p className="text-xs text-slate-500 leading-relaxed font-medium">
                          {bracket.desc}. Higher income allows for greater financial stability and lower interest rates during balance transfers.
                       </p>
                    </div>
                 </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center gap-3 mb-4 text-primary">
                 <span className="material-symbols-outlined">verified</span>
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Tenure & Continuity</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-10 tracking-tight">Professional Continuity</h2>
              <p className="text-slate-500 mb-10 font-medium max-w-xl">Stability is measured by your length of service. Long tenure signals lower risk to credit issuers.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  { id: 'Less than 1 Year', icon: 'history_toggle_off', desc: 'Developing Profile' },
                  { id: '1-2 Years', icon: 'calendar_month', desc: 'Standard Stability' },
                  { id: '2-5 Years', icon: 'verified', desc: 'High Stability' },
                  { id: 'Over 5 Years', icon: 'workspace_premium', desc: 'Elite Stability' }
                ].map(item => (
                  <button 
                    key={item.id}
                    onClick={() => setFormData({...formData, tenure: item.id})}
                    className={`p-8 rounded-[32px] border text-left transition-all group ${formData.tenure === item.id ? 'bg-primary/10 border-primary shadow-xl shadow-primary/10' : 'bg-white/5 border-white/5 hover:border-white/10'}`}
                  >
                    <div className={`size-12 rounded-2xl flex items-center justify-center mb-6 transition-all ${formData.tenure === item.id ? 'bg-primary text-white' : 'bg-white/5 text-slate-600 group-hover:text-white'}`}>
                       <span className="material-symbols-outlined">{item.icon}</span>
                    </div>
                    <p className={`font-black text-xl mb-1 ${formData.tenure === item.id ? 'text-white' : 'text-slate-400'}`}>{item.id}</p>
                    <p className="text-xs text-slate-500 font-medium">{item.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center gap-3 mb-4 text-primary">
                 <span className="material-symbols-outlined">psychology_alt</span>
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Financial Strategy</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-10 tracking-tight">What's your primary goal?</h2>
              
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { id: 'Building Stability', icon: 'shield_with_heart', label: 'Credit Foundation', desc: 'Safe growth' },
                  { id: 'Maximize Points', icon: 'auto_awesome', label: 'Reward Velocity', desc: 'High yield' },
                  { id: 'Luxury Travel', icon: 'flight_takeoff', label: 'Elite Lifestyle', desc: 'Global perks' },
                  { id: 'Emergency Buffer', icon: 'savings', label: 'Cash Reserve', desc: 'Liquidity' },
                  { id: 'Business Growth', icon: 'trending_up', label: 'Enterprise', desc: 'Scale faster' },
                  { id: 'Low Interest', icon: 'account_balance', label: 'Smart Debt', desc: 'Lower APRs' }
                ].map(goal => (
                  <button 
                    key={goal.id}
                    onClick={() => setFormData({...formData, focus: goal.id})}
                    className={`p-8 rounded-[32px] border text-center transition-all group flex flex-col items-center ${formData.focus === goal.id ? 'bg-primary/10 border-primary' : 'bg-white/5 border-white/5 hover:border-white/10'}`}
                  >
                    <span className={`material-symbols-outlined text-4xl mb-4 block transition-all ${formData.focus === goal.id ? 'text-primary' : 'text-slate-600 group-hover:text-white'}`}>{goal.icon}</span>
                    <p className={`font-black text-sm uppercase tracking-widest mb-1 ${formData.focus === goal.id ? 'text-white' : 'text-slate-500'}`}>{goal.label}</p>
                    <p className="text-[10px] text-slate-600 font-bold">{goal.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center gap-3 mb-4 text-primary">
                 <span className="material-symbols-outlined">task_alt</span>
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Eligibility Check</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-12 tracking-tight">Financial Strength Report</h2>
              
              <div className="grid md:grid-cols-2 gap-8 mb-12">
                 <div className="space-y-4">
                    {[
                      { label: 'Income Index', value: `₹${formData.income.toLocaleString()}`, icon: 'payments' },
                      { label: 'Tenure Rating', value: formData.tenure, icon: 'history' },
                      { label: 'Strategic Goal', value: formData.focus, icon: 'target' }
                    ].map((row, i) => (
                      <div key={i} className="flex items-center justify-between p-6 bg-white/5 rounded-3xl border border-white/5">
                         <div className="flex items-center gap-4">
                           <span className="material-symbols-outlined text-slate-500">{row.icon}</span>
                           <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{row.label}</span>
                         </div>
                         <span className="text-sm font-black">{row.value}</span>
                      </div>
                    ))}
                 </div>
                 
                 <div className="bg-[#0a0f18]/40 border border-white/5 p-8 rounded-[40px] flex flex-col justify-center text-center">
                    <p className="text-[10px] font-black text-primary uppercase tracking-[0.4em] mb-4">Estimated Strength</p>
                    <div className="text-6xl font-black text-white mb-4">A+</div>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">
                      Your profile shows <span className="text-emerald-400">strong financial stability</span>. You are highly eligible for cards that offer emergency cash reserves and high-velocity travel points.
                    </p>
                 </div>
              </div>

              <div className="bg-primary/5 border border-primary/10 p-8 rounded-3xl flex gap-6 items-start">
                 <div className="size-12 rounded-2xl bg-primary/20 flex items-center justify-center text-primary shrink-0">
                    <span className="material-symbols-outlined">lightbulb</span>
                 </div>
                 <p className="text-sm text-slate-400 leading-relaxed font-medium">
                    <span className="text-white font-bold">Pro Tip:</span> Based on your stability, we recommend focusing on a card with a <span className="text-white">Balance Transfer Buffer</span> to ensure you can manage any utility fluctuations without high interest.
                 </p>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="mt-16 flex justify-between gap-6 border-t border-white/5 pt-12">
             <button 
               onClick={step === 1 ? undefined : prevStep}
               className={`flex-1 md:flex-none px-12 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${step === 1 ? 'opacity-0 pointer-events-none' : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'}`}
             >
               Back
             </button>
             {step < 4 ? (
               <button 
                onClick={nextStep}
                className="flex-1 md:flex-none px-12 py-4 rounded-2xl bg-primary text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3"
               >
                 Continue Guidance
                 <span className="material-symbols-outlined text-sm">arrow_forward</span>
               </button>
             ) : (
               <button 
                onClick={startAnalysis}
                className="flex-1 md:flex-none px-12 py-4 rounded-2xl bg-primary text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3"
               >
                 Finalize Analysis
                 <span className="material-symbols-outlined text-sm">bolt</span>
               </button>
             )}
          </div>
        </div>

        <p className="mt-12 text-center text-slate-600 text-[10px] font-black uppercase tracking-[0.3em] opacity-50">
          * Professional Financial Analysis Tool • Secure & Encrypted
        </p>
      </div>
      
      <style>{`
        @keyframes loading {
          0% { width: 0%; }
          100% { width: 100%; }
        }
      `}</style>
    </div>
  );
};

export default CardFinder;
