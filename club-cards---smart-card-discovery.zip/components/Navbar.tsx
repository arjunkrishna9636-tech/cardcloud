
import React from 'react';
import { AppView } from '../types';

interface NavbarProps {
  setView: (view: AppView) => void;
  currentView: AppView;
}

const Navbar: React.FC<NavbarProps> = ({ setView, currentView }) => {
  const navItems: { label: string; view: AppView }[] = [
    { label: 'Dashboard', view: 'home' },
    { label: 'Guide', view: 'guide' },
    { label: 'Strategy', view: 'card-strategy' },
    { label: 'Cards', view: 'gallery' },
    { label: 'Wallet', view: 'wallet' },
    { label: 'Offers', view: 'offers' },
    { label: 'Benefits', view: 'benefits' },
    { label: 'Loans', view: 'loans' },
  ];

  return (
    <div className="sticky top-0 z-50 w-full border-b border-white/5 bg-[#0f172a]/80 backdrop-blur-md">
      <div className="max-w-[1440px] mx-auto px-6">
        <header className="flex h-20 items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView('home')}>
            <h2 className="text-white text-xl font-bold tracking-tight">Club Cards</h2>
          </div>
          <nav className="hidden lg:flex items-center gap-6">
            {navItems.map((item) => (
              <button 
                key={item.view}
                onClick={() => setView(item.view)}
                className={`text-[11px] font-black uppercase tracking-widest transition-colors ${currentView === item.view ? 'text-primary' : 'text-slate-400 hover:text-white'}`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 mr-4">
              <button className="size-10 flex items-center justify-center rounded-full bg-white/5 text-slate-400 hover:text-white transition-colors">
                <span className="material-symbols-outlined">notifications</span>
              </button>
              <div className="size-10 rounded-full bg-slate-700 border border-white/10 overflow-hidden cursor-pointer" onClick={() => setView('wallet')}>
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="User" />
              </div>
            </div>
            <button className="h-10 px-6 rounded-lg bg-primary text-[10px] font-black uppercase tracking-widest text-white shadow-lg shadow-primary/30 hover:bg-blue-600 transition-all">
              Log Out
            </button>
          </div>
        </header>
      </div>
    </div>
  );
};

export default Navbar;
