
import React from 'react';
import { CATEGORY_METADATA } from '../constants';
import { CategoryMetadata } from '../types';

interface CategoryBrowserProps {
  onCategorySelect: (category: CategoryMetadata) => void;
}

const CategoryBrowser: React.FC<CategoryBrowserProps> = ({ onCategorySelect }) => {
  return (
    <section className="py-24 bg-[#0a0f18]">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest mb-6">
            <span className="material-symbols-outlined text-sm">grid_view</span>
            Smart Filters
          </div>
          <h2 className="text-5xl font-black text-white mb-4 tracking-tight">Curated Categories</h2>
          <p className="text-slate-500 font-medium max-w-xl mx-auto">Find exactly what suits your lifestyle with our precision-targeted financial clusters.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {CATEGORY_METADATA.map((cat, i) => (
            <button 
              key={i}
              onClick={() => onCategorySelect(cat)}
              className="group p-8 rounded-[40px] bg-white/5 border border-white/5 hover:border-primary/40 hover:bg-primary/5 transition-all duration-500 text-left relative overflow-hidden"
            >
              <div className={`absolute -right-4 -bottom-4 opacity-0 group-hover:opacity-10 transition-all duration-700 text-white`}>
                <span className="material-symbols-outlined text-9xl">{cat.icon}</span>
              </div>
              <div className="size-14 rounded-2xl bg-white/5 flex items-center justify-center text-slate-400 group-hover:bg-primary group-hover:text-white transition-all duration-500 mb-6 shadow-inner">
                <span className="material-symbols-outlined text-3xl">{cat.icon}</span>
              </div>
              <h3 className="text-xl font-black text-white mb-2 group-hover:text-primary transition-colors">{cat.name}</h3>
              <p className="text-sm text-slate-500 font-medium leading-relaxed line-clamp-2">{cat.desc}</p>
              <div className="mt-8 flex items-center gap-2 text-[10px] font-black text-primary uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0">
                Explore Strategy <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryBrowser;
