
import React, { useState } from 'react';
import { GuideChapter } from '../types';

const CHAPTERS: GuideChapter[] = [
  {
    id: 'club-cards-priority',
    title: 'Club Cards Priority System',
    subtitle: 'Credit First, Debit Second',
    icon: 'priority_high',
    mentor: 'Club Cards Prime',
    mentorQuote: 'To build real wealth, you must first master the art of Credit Leverage before Direct Liquidity.',
    topics: [
      { 
        title: 'The Credit-First Protocol', 
        description: 'Why the system prioritizes credit applications to build history length early in the lifecycle.', 
        riskLevel: 'Low' 
      },
      { 
        title: 'Debit as a Yield Asset', 
        description: 'How to transition to high-balance debit instruments only after credit stability is verified.', 
        riskLevel: 'Low' 
      },
      { 
        title: 'Bank-Specific Onboarding', 
        description: 'Analyzing the specific criteria for HDFC and ICICI prime account invitations.', 
        riskLevel: 'Medium',
        isLegal: true
      }
    ]
  },
  {
    id: 'foundations',
    title: 'Financial Architecture',
    subtitle: 'Building from Level Zero',
    icon: 'architecture',
    mentor: 'The Architect',
    mentorQuote: 'Stability is not found in the limit, but in the discipline of the cycle.',
    topics: [
      { 
        title: 'Interest-Free Rotation', 
        description: 'How to utilize the 45-day cycle across 3 cards to maintain 0% cost liquidity.', 
        riskLevel: 'Low' 
      },
      { 
        title: 'RBI Master Circulars', 
        description: 'Understanding your rights regarding card cancellations and billing disputes.', 
        riskLevel: 'Low',
        isLegal: true
      },
      { 
        title: 'The Minimum Due Trap', 
        description: 'Why paying only the minimum incurs 42% annualized interest loss.', 
        riskLevel: 'High' 
      }
    ]
  },
  {
    id: 'advanced',
    title: 'Elite Yield Strategy',
    subtitle: 'High-Velocity Reward Management',
    icon: 'rocket_launch',
    mentor: 'The Strategist',
    mentorQuote: 'Every transaction is an opportunity for a 5% rebate if routed correctly.',
    topics: [
      { 
        title: 'Merchant Category Hacking', 
        description: 'How to use gift vouchers to bypass reward exclusions on utilities.', 
        riskLevel: 'Medium' 
      },
      { 
        title: 'Card-to-Card Leverage', 
        description: 'Using existing high-limit cards to secure "Invite-Only" bank products.', 
        riskLevel: 'Low' 
      },
      { 
        title: 'Forex Fee Mitigation', 
        description: 'Legal ways to avoid the 3.5% markup on international transactions.', 
        riskLevel: 'Low',
        isLegal: true
      }
    ]
  },
  {
    id: 'lifecycle',
    title: 'Wealth Life Cycle',
    subtitle: 'Multi-Generational Credit',
    icon: 'hourglass_empty',
    mentor: 'The Guardian',
    mentorQuote: 'The best time to build credit was 10 years ago. The second best time is today.',
    topics: [
      { 
        title: 'The Student Launchpad', 
        description: 'Transitioning from add-on cards to primary credit files.', 
        riskLevel: 'Low' 
      },
      { 
        title: 'Mortgage Pre-Gaming', 
        description: 'Optimizing your credit profile 12 months before a Home Loan application.', 
        riskLevel: 'Medium' 
      },
      { 
        title: 'Estate Credit Pass-down', 
        description: 'Managing deceased cardholders accounts and liabilities legally.', 
        riskLevel: 'High',
        isLegal: true
      }
    ]
  }
];

const MasterclassGuide: React.FC = () => {
  const [activeChapter, setActiveChapter] = useState(CHAPTERS[0]);
  const [rotationDay, setRotationDay] = useState(15);

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 animate-in fade-in duration-700">
      <div className="max-w-[1440px] mx-auto px-8">
        
        {/* Header with Visual Hero */}
        <div className="grid lg:grid-cols-2 gap-20 items-center mb-24">
           <div>
              <div className="flex items-center gap-3 mb-6 text-primary">
                <span className="material-symbols-outlined">school</span>
                <span className="text-[10px] font-black uppercase tracking-[0.4em]">Club Cards Guide Module v2.0</span>
              </div>
              <h1 className="text-7xl lg:text-9xl font-black tracking-tighter mb-8 leading-none">
                Finance <br/>
                <span className="text-primary italic">Academy.</span>
              </h1>
              <p className="text-xl text-slate-400 max-w-xl font-medium leading-relaxed">
                A definitive guide to mastering the credit life cycle. From RBI compliance to elite card rotation—learn the rules of the <span className="text-white">New Financial Elite</span>.
              </p>
           </div>
           
           {/* Character Illustrator Illustration */}
           <div className="relative group perspective-[1000px]">
              <div className="absolute inset-0 bg-primary/20 blur-[100px] rounded-full scale-75 group-hover:scale-100 transition-transform duration-[3s]"></div>
              <div className="relative z-10 bg-white/5 border border-white/5 rounded-[64px] p-12 backdrop-blur-3xl shadow-2xl overflow-hidden group-hover:rotate-y-6 transition-transform duration-700">
                 <div className="flex items-center gap-8 mb-10">
                    <div className="size-32 rounded-full bg-gradient-to-br from-primary to-blue-700 flex items-center justify-center shadow-2xl shadow-primary/30 group-hover:scale-110 transition-transform">
                       <img src={`https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${activeChapter.mentor}`} alt="Mentor" className="size-20" />
                    </div>
                    <div>
                       <p className="text-sm font-black text-primary uppercase tracking-[0.3em] mb-1">Mentor: {activeChapter.mentor}</p>
                       <p className="text-xl font-black text-white italic leading-tight">"{activeChapter.mentorQuote}"</p>
                    </div>
                 </div>
                 <div className="space-y-4 pt-6 border-t border-white/10">
                    <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-slate-500">
                       <span>Expert Level</span>
                       <span>Certified Specialist</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                       <div className="h-full bg-primary animate-pulse" style={{ width: '85%' }}></div>
                    </div>
                 </div>
              </div>
           </div>
        </div>

        {/* Sidebar + Content Layout */}
        <div className="grid lg:grid-cols-12 gap-16">
          
          {/* Chapter Navigation */}
          <div className="lg:col-span-4 space-y-4">
             <h3 className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-8 ml-4">The Curriculum</h3>
             {CHAPTERS.map(ch => (
               <button
                 key={ch.id}
                 onClick={() => setActiveChapter(ch)}
                 className={`w-full text-left p-8 rounded-[40px] border transition-all duration-500 group relative overflow-hidden ${activeChapter.id === ch.id ? 'bg-white/5 border-primary shadow-2xl scale-105' : 'bg-transparent border-white/5 hover:border-white/10'}`}
               >
                 <div className="flex items-center gap-6 relative z-10">
                    <span className={`material-symbols-outlined text-4xl transition-colors ${activeChapter.id === ch.id ? 'text-primary' : 'text-slate-600 group-hover:text-white'}`}>{ch.icon}</span>
                    <div>
                       <p className="text-xl font-black mb-1">{ch.title}</p>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{ch.subtitle}</p>
                    </div>
                 </div>
                 {activeChapter.id === ch.id && (
                   <div className="absolute right-8 top-1/2 -translate-y-1/2">
                      <span className="material-symbols-outlined text-primary text-3xl">keyboard_double_arrow_right</span>
                   </div>
                 )}
               </button>
             ))}
          </div>

          {/* Chapter Content Area */}
          <div className="lg:col-span-8 space-y-12">
             
             {/* Interactive Rotation Component (Contextual) */}
             {activeChapter.id === 'foundations' && (
               <div className="bg-[#151b27] border border-white/5 rounded-[64px] p-12 lg:p-16 shadow-2xl backdrop-blur-3xl">
                  <h3 className="text-3xl font-black mb-12 flex items-center gap-4">
                    <span className="material-symbols-outlined text-primary text-4xl">autorenew</span>
                    Interactive Rotation Simulator
                  </h3>
                  <div className="space-y-16">
                     <div>
                        <div className="flex justify-between text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-8">
                           <span>Cycle Timeline (Day {rotationDay})</span>
                           <span className="text-white">Interest-Free Window: {50 - rotationDay} Days Remaining</span>
                        </div>
                        <input 
                          type="range" min="1" max="50" value={rotationDay}
                          onChange={(e) => setRotationDay(parseInt(e.target.value))}
                          className="w-full h-3 bg-slate-800 rounded-full appearance-none cursor-pointer accent-primary"
                        />
                     </div>
                     <div className="grid md:grid-cols-3 gap-8">
                        <div className={`p-10 rounded-[32px] border transition-all duration-500 ${rotationDay < 20 ? 'bg-emerald-500/10 border-emerald-500/30 scale-105 shadow-xl' : 'bg-white/5 border-white/5 opacity-40'}`}>
                           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Card A (Spend)</p>
                           <p className="text-2xl font-black">Active Use</p>
                        </div>
                        <div className={`p-10 rounded-[32px] border transition-all duration-500 ${rotationDay >= 20 && rotationDay < 40 ? 'bg-emerald-500/10 border-emerald-500/30 scale-105 shadow-xl' : 'bg-white/5 border-white/5 opacity-40'}`}>
                           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Card B (Rotate)</p>
                           <p className="text-2xl font-black">Primary Yield</p>
                        </div>
                        <div className={`p-10 rounded-[32px] border transition-all duration-500 ${rotationDay >= 40 ? 'bg-red-500/10 border-red-500/30 scale-105 shadow-xl' : 'bg-white/5 border-white/5 opacity-40'}`}>
                           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">Settlement</p>
                           <p className="text-2xl font-black">Clear Balance</p>
                        </div>
                     </div>
                  </div>
               </div>
             )}

             {/* Topic Cards - Premium Layout */}
             <div className="grid md:grid-cols-2 gap-10">
                {activeChapter.topics.map((topic, i) => (
                  <div key={i} className="bg-[#151b27]/60 border border-white/5 rounded-[56px] p-12 group hover:border-primary/30 transition-all shadow-xl relative overflow-hidden flex flex-col">
                     {topic.isLegal && (
                        <div className="absolute top-10 right-10 flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20">
                           <span className="material-symbols-outlined text-[14px] text-blue-400">gavel</span>
                           <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Legal Protocol</span>
                        </div>
                     )}
                     <div className="mb-10 flex justify-between items-start">
                        <div className="size-20 rounded-[24px] bg-white/5 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500 shadow-inner">
                           <span className="material-symbols-outlined text-4xl">{activeChapter.icon}</span>
                        </div>
                        <div className="text-right">
                           <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-2">Stability Check</p>
                           <div className={`text-xs font-black uppercase tracking-widest px-3 py-1 rounded-lg ${topic.riskLevel === 'High' ? 'bg-red-500/10 text-red-400' : topic.riskLevel === 'Medium' ? 'bg-orange-500/10 text-orange-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                              {topic.riskLevel} Risk
                           </div>
                        </div>
                     </div>
                     <h4 className="text-3xl font-black mb-6 tracking-tight group-hover:text-primary transition-colors leading-tight">{topic.title}</h4>
                     <p className="text-lg text-slate-500 font-medium leading-relaxed mb-10 flex-grow">{topic.description}</p>
                     <button className="text-[11px] font-black text-primary uppercase tracking-[0.3em] flex items-center gap-3 group-hover:gap-6 transition-all">
                        Master Module <span className="material-symbols-outlined text-sm">arrow_forward</span>
                     </button>
                  </div>
                ))}
             </div>

             {/* Footer Call to Action */}
             <div className="p-20 bg-gradient-to-br from-[#1258e2] to-[#002855] rounded-[80px] text-center shadow-[0_64px_160px_-40px_rgba(18,88,226,0.6)] relative overflow-hidden group">
                <div className="absolute inset-0 bg-[url('https://api.dicebear.com/7.x/identicon/svg?seed=academy')] opacity-10 mix-blend-overlay scale-125 group-hover:scale-100 transition-transform duration-[10s]"></div>
                <div className="relative z-10">
                   <h2 className="text-5xl lg:text-7xl font-black mb-8 tracking-tighter leading-tight text-white">Advanced Wealth Architecture</h2>
                   <p className="text-xl text-white/80 mb-16 max-w-3xl mx-auto font-medium leading-relaxed">
                      Beyond rotation lies <span className="text-white font-bold italic underline decoration-primary underline-offset-8">wealth preservation</span>. Connect with our elite financial mentors to map your entire bank network for maximum yield.
                   </p>
                   <div className="flex flex-wrap justify-center gap-8">
                      <button className="px-12 py-6 rounded-2xl bg-white text-primary font-black text-[11px] uppercase tracking-[0.3em] shadow-2xl hover:scale-105 active:scale-95 transition-all">
                         Book Private Consultation
                      </button>
                      <button className="px-12 py-6 rounded-2xl bg-white/10 border border-white/20 text-white font-black text-[11px] uppercase tracking-[0.3em] hover:bg-white/20 transition-all">
                         Download RBI Master Audit
                      </button>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MasterclassGuide;
