
import React, { useState } from 'react';

interface DebitPrepaidViewProps {
  type: 'debit' | 'prepaid';
}

const DebitPrepaidView: React.FC<DebitPrepaidViewProps> = ({ type }) => {
  const [filter, setFilter] = useState('All');

  const cards = type === 'debit' ? [
    { name: 'Elite Savings Debit', issuer: 'LUX', perk: '7% Interest on Balance', color: 'from-blue-600 to-blue-900', icon: 'savings' },
    { name: 'Traveler Plus Debit', issuer: 'GLOBE', perk: 'Zero Forex Markup', color: 'from-slate-700 to-slate-900', icon: 'public' },
    { name: 'Wealth Signature', issuer: 'PRIME', perk: 'Airport Lounge Access', color: 'from-emerald-700 to-emerald-900', icon: 'diamond' },
  ] : [
    { name: 'Student Abroad Card', issuer: 'EDU', perk: 'Load 10+ Currencies', color: 'from-purple-600 to-purple-900', icon: 'school' },
    { name: 'Budget Master Prepaid', issuer: 'CORE', perk: 'Spending Analytics', color: 'from-orange-600 to-orange-900', icon: 'query_stats' },
    { name: 'Gift Elite Card', issuer: 'LUX', perk: 'No Expiry • High Limit', color: 'from-pink-600 to-pink-900', icon: 'redeem' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0f18] text-white pt-12 pb-24 px-6 md:px-12 animate-in fade-in duration-700">
      <div className="max-w-[1200px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4 text-primary">
              <span className="material-symbols-outlined">{type === 'debit' ? 'account_balance' : 'payments'}</span>
              <span className="text-[10px] font-black uppercase tracking-[0.4em]">{type} Card Suite</span>
            </div>
            <h1 className="text-5xl font-black tracking-tight mb-4 leading-none capitalize">{type} Card Discovery</h1>
            <p className="text-slate-400 text-lg max-w-xl font-medium">
              Manage your daily spending with our curated {type} instruments designed for financial resilience.
            </p>
          </div>
          <div className="flex p-1.5 bg-white/5 rounded-2xl border border-white/5">
            {['All', 'Lifestyle', 'Travel', 'Rewards'].map(f => (
              <button 
                key={f}
                onClick={() => setFilter(f)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${filter === f ? 'bg-white/5 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {cards.map((card, i) => (
            <div key={i} className="bg-[#151b27]/60 border border-white/5 rounded-[48px] p-10 group hover:border-primary/20 transition-all shadow-2xl overflow-hidden flex flex-col">
              <div className={`aspect-[1.586] rounded-3xl mb-10 relative overflow-hidden bg-gradient-to-br ${card.color} shadow-2xl transition-transform duration-700 group-hover:scale-105`}>
                 <div className="absolute inset-0 bg-white/5 opacity-50 mix-blend-overlay"></div>
                 <div className="relative p-8 h-full flex flex-col justify-between">
                    <div className="flex justify-between items-start">
                       <span className="text-white/40 text-[10px] font-black tracking-[0.4em] uppercase">{card.issuer}</span>
                       <span className="material-symbols-outlined text-white/30 text-2xl">{card.icon}</span>
                    </div>
                    <p className="text-white font-black text-lg tracking-tight uppercase leading-none">{card.name}</p>
                 </div>
              </div>
              <h3 className="text-2xl font-black mb-4 group-hover:text-primary transition-colors">{card.name}</h3>
              <p className="text-sm text-slate-500 font-medium mb-10 leading-relaxed">
                Featured Benefit: <span className="text-white font-bold">{card.perk}</span>. Ideal for users focusing on {filter.toLowerCase()} stability.
              </p>
              <div className="mt-auto pt-8 border-t border-white/5 flex justify-between items-center">
                 <div className="flex flex-col">
                    <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Issuance Fee</span>
                    <span className="text-lg font-black text-white">₹0 <span className="text-xs text-slate-600">Free</span></span>
                 </div>
                 <button className="bg-primary hover:bg-blue-600 text-white p-3 rounded-2xl shadow-xl shadow-primary/20 transition-all">
                    <span className="material-symbols-outlined">arrow_forward</span>
                 </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DebitPrepaidView;
