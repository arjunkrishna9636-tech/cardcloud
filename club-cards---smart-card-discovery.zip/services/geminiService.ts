
import { GoogleGenAI, Type } from "@google/genai";
// Fix: Import ALL_CARDS instead of non-existent FEATURED_CARDS
import { ALL_CARDS } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const getCardRecommendation = async (userInput: string) => {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are a smart financial advisor for "Club Cards". 
    Your goal is to recommend the best credit card from the following list based on user spending habits:
    ${JSON.stringify(ALL_CARDS.map(c => ({ id: c.id, name: c.name, description: c.description, rewards: c.rewards })))}
    
    If none of these are perfect, still pick the closest match.
    Respond only in JSON format with two fields: "cardId" (the ID of the recommended card) and "reason" (a short 1-sentence explanation).
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: userInput,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            cardId: { type: Type.STRING },
            reason: { type: Type.STRING }
          },
          required: ["cardId", "reason"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};
