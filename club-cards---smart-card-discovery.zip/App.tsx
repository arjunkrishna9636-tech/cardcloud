
import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import CardComparison from './components/CardComparison';
import CreditScore from './components/CreditScore';
import CardGallery from './components/CardGallery';
import TrendingCards from './components/TrendingCards';
import TrustSection from './components/TrustSection';
import CategoryBrowser from './components/CategoryBrowser';
import Footer from './components/Footer';
import AICardFinder from './components/AICardFinder';
import CuratedCards from './components/CuratedCards';
import MyWallet from './components/MyWallet';
import BillingInsights from './components/BillingInsights';
import CardFinder from './components/CardFinder';
import LoansView from './components/LoansView';
import DebitPrepaidView from './components/DebitPrepaidView';
import OffersView from './components/OffersView';
import MyBenefits from './components/MyBenefits';
import CardStrategyView from './components/CardStrategyView';
import MasterclassGuide from './components/MasterclassGuide';
import CategoryDetail from './components/CategoryDetail';
import { AppView, CategoryMetadata } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('home');
  const [finderData, setFinderData] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState<CategoryMetadata | null>(null);

  const handleFinderComplete = (data: any) => {
    setFinderData(data);
    setView('curated');
  };

  const handleCategorySelect = (category: CategoryMetadata) => {
    setSelectedCategory(category);
    setView('category-detail');
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-background-light dark:bg-[#0a0f18] group/design-root selection:bg-primary selection:text-white overflow-x-hidden font-sans">
      <Navbar setView={setView} currentView={view} />
      
      <main className="flex-grow">
        {view === 'home' && (
          <div className="animate-in fade-in slide-in-from-top-4 duration-700">
            <Hero onFindCard={() => setView('finder')} />
            <Features 
              onStartCompare={() => setView('compare')} 
              onCheckScore={() => setView('score')}
              onSeeMatches={() => setView('finder')}
            />
            <CategoryBrowser onCategorySelect={handleCategorySelect} />
            <TrendingCards onViewAll={() => setView('gallery')} />
            <TrustSection />
          </div>
        )}
        {view === 'compare' && <CardComparison />}
        {view === 'score' && <CreditScore />}
        {view === 'gallery' && <CardGallery />}
        {view === 'curated' && <CuratedCards userData={finderData} />}
        {view === 'wallet' && <MyWallet />}
        {view === 'billing' && <BillingInsights />}
        {view === 'finder' && <CardFinder onComplete={handleFinderComplete} />}
        {view === 'loans' && <LoansView />}
        {view === 'debit' && <DebitPrepaidView type="debit" />}
        {view === 'prepaid' && <DebitPrepaidView type="prepaid" />}
        {view === 'offers' && <OffersView />}
        {view === 'benefits' && <MyBenefits />}
        {view === 'card-strategy' && <CardStrategyView />}
        {view === 'guide' && <MasterclassGuide />}
        {view === 'category-detail' && selectedCategory && (
          <CategoryDetail 
            category={selectedCategory} 
            onBack={() => setView('home')} 
          />
        )}
      </main>

      {(view !== 'wallet' && view !== 'billing' && view !== 'finder' && view !== 'loans' && view !== 'offers' && view !== 'benefits' && view !== 'card-strategy' && view !== 'guide') && <Footer />}
      
      <AICardFinder />
    </div>
  );
};

export default App;
